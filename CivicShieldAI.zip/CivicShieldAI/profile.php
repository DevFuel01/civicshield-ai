<?php
// ─────────────────────────────────────────────
//  CivicShield AI — User Profile Page
// ─────────────────────────────────────────────
require_once __DIR__ . '/config/database.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Profile — CivicShield AI</title>
    <meta name="description" content="View and manage your CivicShield AI profile, track your submitted reports, and see AI analysis results.">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* ─── Profile Layout ─────────────────────── */
        .profile-page {
            padding-top: 80px;
            min-height: 100vh;
        }

        .profile-wrap {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem 1.5rem 4rem;
        }

        /* ─── Profile Header Card ────────────────── */
        .profile-header-card {
            background: linear-gradient(135deg, rgba(99, 102, 241, .25), rgba(6, 182, 212, .15));
            border: 1px solid rgba(99, 102, 241, .3);
            border-radius: var(--radius-lg);
            padding: 2rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        .avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            display: grid;
            place-items: center;
            font-size: 2rem;
            font-weight: 900;
            color: #fff;
            flex-shrink: 0;
            box-shadow: 0 4px 20px rgba(99, 102, 241, .4);
        }

        .profile-info__name {
            font-size: 1.6rem;
            font-weight: 800;
        }

        .profile-info__email {
            color: var(--text-2);
            font-size: .9rem;
        }

        .profile-info__role {
            margin-top: .4rem;
        }

        .profile-header-stats {
            margin-left: auto;
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .ph-stat__value {
            font-size: 1.75rem;
            font-weight: 900;
            text-align: center;
        }

        .ph-stat__label {
            font-size: .75rem;
            color: var(--text-2);
            text-align: center;
        }

        /* ─── Tabs ───────────────────────────────── */
        .tabs {
            display: flex;
            gap: .25rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid var(--border);
        }

        .tab-btn {
            padding: .6rem 1.1rem;
            background: none;
            border: none;
            border-bottom: 2px solid transparent;
            color: var(--text-2);
            font-size: .875rem;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--transition);
            margin-bottom: -1px;
        }

        .tab-btn:hover {
            color: var(--text);
        }

        .tab-btn.active {
            color: var(--primary-light);
            border-bottom-color: var(--primary-light);
        }

        .tab-panel {
            display: none;
        }

        .tab-panel.active {
            display: block;
            animation: fadeIn .3s ease;
        }

        /* ─── Report History Card ────────────────── */
        .report-history-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.25rem;
            margin-bottom: 1rem;
            transition: all var(--transition);
        }

        .report-history-card:hover {
            border-color: rgba(99, 102, 241, .35);
            box-shadow: var(--glow);
        }

        .rhc-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 1rem;
            margin-bottom: .75rem;
            flex-wrap: wrap;
        }

        .rhc-title {
            font-weight: 700;
            font-size: .95rem;
            margin-bottom: .25rem;
        }

        .rhc-meta {
            font-size: .78rem;
            color: var(--text-3);
        }

        .rhc-badges {
            display: flex;
            gap: .4rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .rhc-score {
            font-size: .85rem;
            font-weight: 800;
            padding: .15rem .55rem;
            border-radius: 99px;
        }

        .ai-block {
            background: var(--surface-2);
            border-radius: var(--radius-sm);
            padding: .75rem 1rem;
            margin-top: .75rem;
        }

        .ai-block__label {
            font-size: .7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .05em;
            color: var(--text-3);
            margin-bottom: .25rem;
        }

        .ai-block__text {
            font-size: .825rem;
            color: var(--text-2);
        }

        /* ─── Edit Form ──────────────────────────── */
        .profile-form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.25rem;
        }

        @media(max-width:640px) {
            .profile-form-grid {
                grid-template-columns: 1fr;
            }
        }

        .divider {
            border: none;
            border-top: 1px solid var(--border);
            margin: 1.5rem 0;
        }

        /* ─── Empty / Loading ────────────────────── */
        .empty-profile {
            text-align: center;
            padding: 3rem;
            color: var(--text-3);
        }

        .empty-profile__icon {
            font-size: 2.5rem;
            margin-bottom: .75rem;
        }
    </style>
</head>

<body>

    <!-- ═══ NAVBAR ════════════════════════════════ -->
    <nav class="navbar">
        <a href="index.php" class="navbar__logo">
            <div class="navbar__logo-icon">🛡️</div>
            CivicShield <span class="text-gradient">AI</span>
        </a>
        <button class="hamburger" id="hamburger" aria-label="Menu">
            <span></span><span></span><span></span>
        </button>
        <ul class="navbar__links" id="navbar-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="report_issue.php">Report Issue</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="profile.php" class="active">Profile</a></li>
        </ul>
        <div class="navbar__actions">
            <div id="nav-auth-buttons" style="display:flex;gap:.5rem">
                <button class="btn btn-secondary btn-sm" data-auth-open="login">Sign In</button>
                <button class="btn btn-primary btn-sm" data-auth-open="register">Get Started</button>
            </div>
            <div id="nav-user-info" style="display:none;align-items:center;gap:.75rem">
                <span style="font-size:.875rem;color:var(--text-2)">👤 <strong id="nav-user-name"></strong></span>
                <button class="btn btn-secondary btn-sm" data-logout>Sign Out</button>
            </div>
        </div>
    </nav>

    <!-- ═══ PROFILE PAGE ═══════════════════════════ -->
    <div class="profile-page">
        <div class="profile-wrap">

            <!-- Loading state -->
            <div id="profile-loading" style="text-align:center;padding:4rem;color:var(--text-3)">
                <span class="spinner spinner-lg"></span>
                <p style="margin-top:1rem">Loading your profile…</p>
            </div>

            <!-- Auth required state -->
            <div id="profile-auth-required" style="display:none">
                <div class="card" style="text-align:center;padding:3rem;max-width:400px;margin:0 auto">
                    <div style="font-size:2.5rem;margin-bottom:1rem">🔐</div>
                    <h2 style="margin-bottom:.5rem">Login Required</h2>
                    <p style="color:var(--text-2);margin-bottom:1.5rem">Please sign in to view your profile.</p>
                    <button class="btn btn-primary btn-block" onclick="openAuthModal('login')">Sign In</button>
                </div>
            </div>

            <!-- Profile content (rendered by JS) -->
            <div id="profile-content" style="display:none">

                <!-- Header card -->
                <div class="profile-header-card" id="profile-header-card">
                    <div class="avatar" id="profile-avatar"></div>
                    <div class="profile-info">
                        <div class="profile-info__name" id="profile-name-display"></div>
                        <div class="profile-info__email" id="profile-email-display"></div>
                        <div class="profile-info__role">
                            <span class="badge" id="profile-role-badge"></span>
                        </div>
                    </div>
                    <div class="profile-header-stats">
                        <div class="ph-stat">
                            <div class="ph-stat__value text-gradient" id="ph-stat-total">—</div>
                            <div class="ph-stat__label">Total Reports</div>
                        </div>
                        <div class="ph-stat">
                            <div class="ph-stat__value" style="color:var(--sev-low)" id="ph-stat-resolved">—</div>
                            <div class="ph-stat__label">Resolved</div>
                        </div>
                        <div class="ph-stat">
                            <div class="ph-stat__value" style="color:var(--status-pending)" id="ph-stat-pending">—</div>
                            <div class="ph-stat__label">Pending</div>
                        </div>
                    </div>
                </div>

                <!-- Tabs -->
                <div class="tabs">
                    <button class="tab-btn active" data-tab="reports">📋 My Reports</button>
                    <button class="tab-btn" data-tab="edit">✏️ Edit Profile</button>
                    <button class="tab-btn" data-tab="password">🔒 Change Password</button>
                </div>

                <!-- ─── TAB: My Reports ──────────────────────── -->
                <div class="tab-panel active" id="tab-reports">
                    <div id="reports-list">
                        <div style="text-align:center;padding:2rem;color:var(--text-3)">
                            <span class="spinner"></span>
                        </div>
                    </div>
                </div>

                <!-- ─── TAB: Edit Profile ────────────────────── -->
                <div class="tab-panel" id="tab-edit">
                    <div class="card" style="max-width:580px">
                        <h3 style="margin-bottom:1.25rem">✏️ Edit Profile Details</h3>
                        <form id="edit-profile-form" novalidate>
                            <div class="profile-form-grid">
                                <div class="form-group">
                                    <label class="form-label" for="edit-name">Full Name</label>
                                    <input class="form-control" id="edit-name" type="text" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="edit-email">Email Address</label>
                                    <input class="form-control" id="edit-email" type="email" required>
                                </div>
                            </div>
                            <p id="edit-error" class="form-error" style="display:none"></p>
                            <p id="edit-success" style="color:var(--sev-low);font-size:.875rem;display:none">✅ Profile updated successfully!</p>
                            <button class="btn btn-primary" type="submit" id="edit-submit-btn">Save Changes</button>
                        </form>

                        <hr class="divider">

                        <div style="padding: .5rem 0">
                            <h4 style="color:var(--text-2);margin-bottom:.5rem;font-size:.875rem">Account Details</h4>
                            <p style="font-size:.825rem;color:var(--text-3)">
                                Member since: <strong id="profile-joined" style="color:var(--text-2)"></strong>
                            </p>
                            <p style="font-size:.825rem;color:var(--text-3);margin-top:.25rem">
                                Role: <strong id="profile-role-text" style="color:var(--text-2)"></strong>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- ─── TAB: Change Password ──────────────────── -->
                <div class="tab-panel" id="tab-password">
                    <div class="card" style="max-width:440px">
                        <h3 style="margin-bottom:1.25rem">🔒 Change Password</h3>
                        <form id="change-password-form" novalidate>
                            <div class="form-group">
                                <label class="form-label" for="current-password">Current Password</label>
                                <input class="form-control" id="current-password" type="password" autocomplete="current-password" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="new-password">New Password
                                    <span class="form-hint" style="display:inline">(min 6 chars)</span>
                                </label>
                                <input class="form-control" id="new-password" type="password" autocomplete="new-password" required minlength="6">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="confirm-password">Confirm New Password</label>
                                <input class="form-control" id="confirm-password" type="password" required>
                            </div>
                            <p id="pw-error" class="form-error" style="display:none"></p>
                            <p id="pw-success" style="color:var(--sev-low);font-size:.875rem;display:none">✅ Password changed successfully!</p>
                            <button class="btn btn-primary" type="submit" id="pw-submit-btn">Update Password</button>
                        </form>
                    </div>
                </div>

            </div><!-- /profile-content -->
        </div>
    </div>

    <div id="toast-container"></div>

    <script src="assets/js/utils.js"></script>
    <script src="assets/js/auth.js"></script>
    <script>
        document.getElementById('hamburger').addEventListener('click', () => {
            document.getElementById('navbar-links').classList.toggle('open');
        });

        // ─── Tab switching ────────────────────────────
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
                btn.classList.add('active');
                document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
            });
        });

        // ─── Load profile data ─────────────────────────
        async function loadProfile() {
            const user = await getSessionUser();
            document.getElementById('profile-loading').style.display = 'none';

            if (!user) {
                document.getElementById('profile-auth-required').style.display = '';
                return;
            }

            try {
                const data = await apiFetch('api/profile.php');

                document.getElementById('profile-content').style.display = '';

                // Header
                const initial = (data.profile.name || '?')[0].toUpperCase();
                document.getElementById('profile-avatar').textContent = initial;
                document.getElementById('profile-name-display').textContent = data.profile.name;
                document.getElementById('profile-email-display').textContent = data.profile.email;
                document.getElementById('ph-stat-total').textContent = data.stats.total;
                document.getElementById('ph-stat-resolved').textContent = data.stats.resolved;
                document.getElementById('ph-stat-pending').textContent = data.stats.pending;

                const roleBadge = document.getElementById('profile-role-badge');
                roleBadge.textContent = data.profile.role === 'admin' ? '⭐ Admin' : '👤 Citizen';
                roleBadge.className = 'badge ' + (data.profile.role === 'admin' ? 'badge-electrical' : 'badge-other');

                // Edit form pre-fill
                document.getElementById('edit-name').value = data.profile.name;
                document.getElementById('edit-email').value = data.profile.email;
                document.getElementById('profile-joined').textContent = formatDate(data.profile.created_at);
                document.getElementById('profile-role-text').textContent = data.profile.role === 'admin' ? 'Admin' : 'Citizen';

                // Reports list
                renderReportHistory(data.reports);

            } catch (e) {
                showToast('Failed to load profile: ' + e.message, 'error');
            }
        }

        // ─── Render personal report history ─────────────
        function renderReportHistory(reports) {
            const container = document.getElementById('reports-list');
            if (!reports || reports.length === 0) {
                container.innerHTML = `
          <div class="empty-profile">
            <div class="empty-profile__icon">📭</div>
            <h3 style="margin-bottom:.5rem">No reports yet</h3>
            <p>You haven't submitted any civic reports yet.</p>
            <a href="report_issue.php" class="btn btn-primary" style="margin-top:1rem">🚨 Submit Your First Report</a>
          </div>`;
                return;
            }

            container.innerHTML = reports.map(r => {
                const score = r.ai_severity_score;
                const scoreColor = getSeverityColor(score);
                const catIcons = {
                    pothole: '🕳️',
                    electrical: '⚡',
                    flooding: '🌊',
                    waste: '🗑️',
                    'structural damage': '🏗️',
                    other: '📌'
                };
                const catIcon = catIcons[r.ai_category] || '📌';

                return `
        <div class="report-history-card">
          <div class="rhc-top">
            <div>
              <div class="rhc-title">${catIcon} ${escapeHtml(r.title)}</div>
              <div class="rhc-meta">Submitted ${formatDateTime(r.created_at)}</div>
            </div>
            <div class="rhc-badges">
              ${r.ai_category
                ? `<span class="badge badge-${r.ai_category.replace(/\s+/g,'-')}">${r.ai_category}</span>`
                : ''}
              ${statusBadge(r.status)}
              ${score !== null
                ? `<span class="rhc-score" style="color:${scoreColor};background:${scoreColor}22">⚡ ${score}/100</span>`
                : ''}
            </div>
          </div>

          <p style="font-size:.85rem;color:var(--text-2);margin-bottom:${r.ai_summary ? '.75rem' : '0'}">${escapeHtml(r.description).substring(0,160)}${r.description.length > 160 ? '…' : ''}</p>

          ${r.ai_summary ? `
          <div class="ai-block">
            <div class="ai-block__label">🤖 AI Summary</div>
            <div class="ai-block__text">${escapeHtml(r.ai_summary)}</div>
          </div>` : ''}

          ${r.ai_recommendation ? `
          <div class="ai-block" style="margin-top:.5rem">
            <div class="ai-block__label">🔧 Recommendation</div>
            <div class="ai-block__text">${escapeHtml(r.ai_recommendation)}</div>
          </div>` : ''}

          ${!r.ai_summary ? `<p style="font-size:.78rem;color:var(--text-3);margin-top:.5rem;font-style:italic">⏳ AI analysis pending…</p>` : ''}
        </div>`;
            }).join('');
        }

        function escapeHtml(str) {
            if (!str) return '';
            return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        // ─── Edit profile form ─────────────────────────
        document.getElementById('edit-profile-form').addEventListener('submit', async e => {
            e.preventDefault();
            const errEl = document.getElementById('edit-error');
            const sucEl = document.getElementById('edit-success');
            const btn = document.getElementById('edit-submit-btn');
            errEl.style.display = 'none';
            sucEl.style.display = 'none';
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner"></span> Saving…';

            try {
                const res = await apiFetch('api/profile.php?action=update', {
                    method: 'PATCH',
                    body: JSON.stringify({
                        name: document.getElementById('edit-name').value.trim(),
                        email: document.getElementById('edit-email').value.trim(),
                    }),
                });
                sucEl.style.display = '';
                // Update header display
                document.getElementById('profile-name-display').textContent = res.name;
                document.getElementById('profile-email-display').textContent = res.email;
                document.getElementById('profile-avatar').textContent = res.name[0].toUpperCase();
                document.getElementById('nav-user-name').textContent = res.name;
                showToast('Profile updated! ✅', 'success');
            } catch (err) {
                errEl.textContent = err.message;
                errEl.style.display = '';
            } finally {
                btn.disabled = false;
                btn.innerHTML = 'Save Changes';
            }
        });

        // ─── Change password form ──────────────────────
        document.getElementById('change-password-form').addEventListener('submit', async e => {
            e.preventDefault();
            const errEl = document.getElementById('pw-error');
            const sucEl = document.getElementById('pw-success');
            const btn = document.getElementById('pw-submit-btn');
            const newPw = document.getElementById('new-password').value;
            const confPw = document.getElementById('confirm-password').value;

            errEl.style.display = 'none';
            sucEl.style.display = 'none';

            if (newPw !== confPw) {
                errEl.textContent = 'New passwords do not match.';
                errEl.style.display = '';
                return;
            }

            btn.disabled = true;
            btn.innerHTML = '<span class="spinner"></span> Updating…';

            try {
                await apiFetch('api/profile.php?action=password', {
                    method: 'PATCH',
                    body: JSON.stringify({
                        current_password: document.getElementById('current-password').value,
                        new_password: newPw,
                    }),
                });
                sucEl.style.display = '';
                document.getElementById('change-password-form').reset();
                showToast('Password changed successfully! 🔒', 'success');
            } catch (err) {
                errEl.textContent = err.message;
                errEl.style.display = '';
            } finally {
                btn.disabled = false;
                btn.innerHTML = 'Update Password';
            }
        });

        // Initialize
        loadProfile();
    </script>
</body>

</html>