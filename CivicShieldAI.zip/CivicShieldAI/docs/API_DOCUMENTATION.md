# CivicShield AI — REST API Documentation

This document provides a detailed reference for all API endpoints in the CivicShield AI platform. All endpoints are located in the `/api/` directory and return JSON responses.

---

## 🔐 Authentication (`/api/auth.php`)

All state-changing requests (POST, PATCH) require a valid session and a CSRF token passed via the `X-CSRF-Token` header.

### `GET ?action=me`
Returns the current session user info.
- **Response (200 OK):**
  ```json
  {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "role": "citizen"
  }
  ```

### `POST ?action=login`
Authenticates a user and starts a session.
- **Body:** `{ "email": "...", "password": "..." }`
- **Response (200 OK):** `{ "success": true, "user": { ... } }`

---

## 📬 Reports (`/api/report.php`)

### `GET /`
List reports with optional filters and sorting.
- **Query Params:**
  - `status`: `pending`, `in-progress`, `resolved`
  - `category`: `pothole`, `electrical`, etc.
  - `search`: Keyword string
  - `sw_lat`, `sw_lng`, `ne_lat`, `ne_lng`: Geographic bounds
  - `sort`: `recent`, `risk`, `density`, `intelligent`
  - `page`, `limit`: Pagination controls
- **Response:** Array of report objects.

### `POST /`
Create a new report.
- **Body (Multipart):** `title`, `description`, `image` (file), `latitude`, `longitude`, `landmark`, `zone`.
- **Response (201 Created):** `{ "success": true, "report_id": 123 }`

### `PATCH ?id=X` (Admin)
Update report status or admin notes.
- **Body:** `{ "status": "...", "admin_notes": "...", "timeline_message": "..." }`
- **Response (200 OK):** `{ "success": true }`

---

## 🤖 AI Processing (`/api/ai-process.php`)

### `POST /`
Triggers Gemini AI analysis for a report. Usually called immediately after report creation.
- **Body:** `{ "report_id": 123 }`
- **Response:**
  ```json
  {
    "category": "pothole",
    "severity_score": 85,
    "priority": "critical",
    "summary": "Deep pothole identified...",
    "recommendation": "Emergency repair recommended.",
    "department": "Public Works",
    "tags": ["traffic_risk", "near_school"]
  }
  ```

---

## 📊 Analytics (`/api/analytics.php`)

### `GET ?type=stats`
High-level platform statistics.
- **Response:** `{ "total": 150, "resolved": 45, "pending": 105, "avg_severity": 62 }`

### `GET ?type=categories`
Data for category distribution charts.

### `GET ?type=timeline`
Report volume over time. Supports `?days=N`.

### `GET ?type=predictive`
Identifies "High Risk Zones" and "Watchlist Zones" based on recent growth and average severity.

---

## ⏳ Timeline (`/api/timeline.php`)

### `GET ?report_id=X`
Retrieves the full lifecycle history of a report. Used by the citizen tracking view.
- **Response:** Array of timeline events sorted by date.
