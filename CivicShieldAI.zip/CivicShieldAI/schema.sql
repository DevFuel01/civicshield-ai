-- ==============================================================
--  CivicShield AI - Database Schema
--  Run: mysql -u root < schema.sql
--  Or import via phpMyAdmin
-- ==============================================================

CREATE DATABASE IF NOT EXISTS `civicshield`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `civicshield`;

-- -------------------------------------------------------
--  Table: users
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id`         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `name`       VARCHAR(120)    NOT NULL,
    `email`      VARCHAR(180)    NOT NULL,
    `password`   VARCHAR(255)    NOT NULL,
    `role`       ENUM('citizen','admin') NOT NULL DEFAULT 'citizen',
    `created_at` TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
--  Table: reports
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reports` (
    `id`                INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `user_id`           INT UNSIGNED    NOT NULL,
    `title`             VARCHAR(255)    NOT NULL,
    `description`       TEXT            NOT NULL,
    `image_path`        VARCHAR(500)        NULL,
    `latitude`          DECIMAL(10,7)       NULL,
    `longitude`         DECIMAL(10,7)       NULL,
    `landmark`          VARCHAR(255)        NULL,
    `zone`              VARCHAR(120)        NULL,
    `address`           VARCHAR(500)        NULL,
    `ai_category`       ENUM('pothole','electrical','flooding','waste','structural damage','other') NULL,
    `ai_severity_score` TINYINT UNSIGNED    NULL COMMENT '0-100',
    `ai_priority`       ENUM('low','medium','high','critical') NULL,
    `status`            ENUM('pending','in-progress','resolved') NOT NULL DEFAULT 'pending',
    `created_at`        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user_id`           (`user_id`),
    KEY `idx_latitude`          (`latitude`),
    KEY `idx_longitude`         (`longitude`),
    KEY `idx_status`            (`status`),
    KEY `idx_ai_severity_score` (`ai_severity_score`),
    KEY `idx_ai_category`       (`ai_category`),
    KEY `idx_zone`              (`zone`),
    KEY `idx_created_at`        (`created_at`),
    CONSTRAINT `fk_reports_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
--  Table: analytics_logs
-- -------------------------------------------------------
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
--  Table: report_timeline
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `report_timeline` (
    `id`                INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `report_id`         INT UNSIGNED  NOT NULL,
    `status`            VARCHAR(50)   NOT NULL,
    `message`           TEXT              NULL,
    `created_at`        TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_report_id` (`report_id`),
    CONSTRAINT `fk_timeline_report`
        FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
--  Seed: default admin account
--  password = Admin@123 (bcrypt)
-- -------------------------------------------------------
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `role`) VALUES
('CivicShield Admin', 'admin@civicshield.ai',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- -------------------------------------------------------
--  Seed: sample reports for demo dashboard
-- -------------------------------------------------------
INSERT IGNORE INTO `reports`
    (`user_id`,`title`,`description`,`latitude`,`longitude`,`ai_category`,`ai_severity_score`,`status`)
VALUES
    (1,'Large pothole on Main Street','Deep pothole causing vehicle damage near traffic lights.',6.4541,3.3947,'pothole',78,'pending'),
    (1,'Broken streetlight at Junction','Streetlight has been off for 3 weeks creating safety risk.',6.4550,3.3960,'electrical',65,'in-progress'),
    (1,'Flooding on Lagos Road','Stagnant water after rain is blocking pedestrian access.',6.4530,3.3935,'flooding',85,'pending'),
    (1,'Illegal dumping near school','Large pile of waste dumped beside primary school entrance.',6.4560,3.3970,'waste',55,'pending'),
    (1,'Cracked bridge structure','Visible cracks on pedestrian bridge, risk of collapse.',6.4515,3.3920,'structural damage',92,'pending'),
    (1,'Pothole cluster Adeola Ave','Multiple potholes spanning 200m of road surface.',6.4575,3.3990,'pothole',70,'in-progress'),
    (1,'Burst water pipe flooding road','Water pipe burst causing flooding and traffic disruption.',6.4490,3.3910,'flooding',80,'resolved'),
    (1,'Fallen electrical pole','Electrical pole fallen across road after storm damage.',6.4500,3.3980,'electrical',88,'pending'),
    (1,'Overflowing skip bins','Public skip bins overflowing outside shopping centre.',6.4580,3.4000,'waste',45,'resolved'),
    (1,'Subsidence on Bridge Road','Road surface sinking near drainage culvert.',6.4510,3.3930,'structural damage',75,'pending');

-- -------------------------------------------------------
--  Seed: analytics_logs for sample reports
-- -------------------------------------------------------
INSERT IGNORE INTO `analytics_logs` (`report_id`,`ai_summary`,`ai_recommendation`) VALUES
(1,'Severe pothole creating vehicular hazard at busy intersection.','Immediate patching required. Deploy road crew within 48 hours.'),
(2,'Persistent electrical fault posing night-time safety risk.','Engage utility provider for urgent lamp replacement.'),
(3,'Flash-flood risk area requiring drainage improvement.','Install additional storm drains; temporary barriers needed.'),
(4,'Health hazard from illegal waste accumulation near school.','Schedule emergency waste removal and enforce dumping fines.'),
(5,'Critical structural integrity risk - bridge requires inspection.','Close bridge immediately; commission structural engineer assessment.'),
(6,'High-density pothole cluster causing ongoing vehicle damage.','Full road resurfacing recommended within 2 weeks.'),
(7,'Major pipe burst resolved but road damage remains.','Inspect road surface for subsidence following water damage.'),
(8,'Downed electrical infrastructure blocking traffic.','Emergency utility response; set up safety perimeter.'),
(9,'Waste management issue resolved by collection team.','Review pickup schedule to prevent recurrence.'),
(10,'Road subsidence indicating underlying drainage failure.','Geotechnical survey required before repair.');
