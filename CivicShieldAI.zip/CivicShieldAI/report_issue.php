<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Report Issue Page
// ─────────────────────────────────────────────
require_once __DIR__ . '/config/database.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Report an Issue — CivicShield AI</title>
    <meta name="description" content="Submit a civic infrastructure issue report. Our AI will classify, score severity, and recommend an action plan instantly.">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/report.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        /* ── Map Pin Selector ─────────────────── */
        .map-selector-wrap {
            border-radius: var(--radius);
            overflow: hidden;
            border: 1px solid var(--border);
            margin-top: .75rem;
            transition: border-color var(--transition);
        }

        .map-selector-wrap:focus-within,
        .map-selector-wrap.active {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, .15);
        }

        #pin-map {
            height: 280px;
            cursor: crosshair !important;
        }

        .map-selector-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: .6rem 1rem;
            background: var(--surface-2);
            border-bottom: 1px solid var(--border);
            font-size: .8rem;
        }

        .map-selector-tip {
            color: var(--text-3);
            font-style: italic;
        }

        .map-selector-coords {
            color: var(--accent);
            font-weight: 600;
        }

        /* ── Address Display ──────────────────── */
        .address-display {
            display: flex;
            align-items: flex-start;
            gap: .6rem;
            background: rgba(6, 182, 212, .07);
            border: 1px solid rgba(6, 182, 212, .2);
            border-radius: var(--radius-sm);
            padding: .65rem .9rem;
            margin-top: .6rem;
            font-size: .85rem;
            color: var(--text-2);
            display: none;
        }

        .address-display.visible {
            display: flex;
        }

        .address-display__icon {
            font-size: 1rem;
            flex-shrink: 0;
            margin-top: .05rem;
        }

        /* ── Location Methods ─────────────────── */
        .location-methods {
            display: flex;
            gap: .5rem;
            margin-bottom: .75rem;
            flex-wrap: wrap;
        }

        .loc-method-btn {
            flex: 1;
            min-width: 120px;
            padding: .5rem .75rem;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            background: var(--surface-2);
            color: var(--text-2);
            font-size: .8rem;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--transition);
            text-align: center;
        }

        .loc-method-btn:hover,
        .loc-method-btn.active {
            border-color: var(--primary);
            background: rgba(99, 102, 241, .1);
            color: var(--primary-light);
        }

        /* ── Geocoding spinner ────────────────── */
        .geocoding-state {
            font-size: .78rem;
            color: var(--text-3);
            display: flex;
            align-items: center;
            gap: .4rem;
            margin-top: .4rem;
            min-height: 1.2rem;
        }
    </style>
</head>

<body>

    <!-- ═══ NAVBAR ════════════════════════════════ -->
    <nav class="navbar">
        <a href="index.php" class="navbar__logo">
            <div class="navbar__logo-icon">🛡️</div>
            CivicShield <span class="text-gradient">AI</span>
        </a>
        <button class="hamburger" id="hamburger" aria-label="Menu">
            <span></span><span></span><span></span>
        </button>
        <ul class="navbar__links" id="navbar-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="report_issue.php" class="active">Report Issue</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="profile.php">Profile</a></li>
        </ul>
        <div class="navbar__actions">
            <div id="nav-auth-buttons" style="display:flex;gap:.5rem">
                <button class="btn btn-secondary btn-sm" data-auth-open="login">Sign In</button>
                <button class="btn btn-primary btn-sm" data-auth-open="register">Get Started</button>
            </div>
            <div id="nav-user-info" style="display:none;align-items:center;gap:.75rem">
                <span style="font-size:.875rem;color:var(--text-2)">👤 <strong id="nav-user-name"></strong></span>
                <button class="btn btn-secondary btn-sm" data-logout>Sign Out</button>
            </div>
        </div>
    </nav>

    <!-- ═══ PAGE ══════════════════════════════════ -->
    <div class="report-page">
        <div class="report-container">

            <!-- Header -->
            <div class="report-header">
                <div class="report-header__eyebrow">🚨 Civic Reporting</div>
                <h1>Report an Issue <span class="text-gradient">in Your Area</span></h1>
                <p>Fill in the details below. Our AI will instantly classify your report and generate an actionable recommendation.</p>
            </div>

            <!-- Step Indicator -->
            <div class="form-steps" style="margin-bottom:2rem">
                <div class="form-step active" id="step-1">
                    <div class="form-step__num">1</div>
                    <span>Details</span>
                </div>
                <div class="form-step__line"></div>
                <div class="form-step" id="step-2">
                    <div class="form-step__num">2</div>
                    <span>Location</span>
                </div>
                <div class="form-step__line"></div>
                <div class="form-step" id="step-3">
                    <div class="form-step__num">3</div>
                    <span>AI Result</span>
                </div>
            </div>

            <!-- ════ REPORT FORM ═══════════════════════ -->
            <div class="report-form-card" id="report-form-card">
                <form id="report-form" novalidate enctype="multipart/form-data">
                    <!-- Anti-spam Honeypot (hidden from users) -->
                    <div style="display:none !important">
                        <label>Leave this field blank</label>
                        <input type="text" name="phone_alt" id="phone_alt" tabindex="-1" autocomplete="off">
                    </div>

                    <!-- Title -->
                    <div class="form-group">
                        <label class="form-label" for="report-title">Issue Title <span style="color:var(--sev-critical)">*</span></label>
                        <input class="form-control" id="report-title" type="text"
                            placeholder="e.g. Large pothole on Main Street" maxlength="200" required>
                    </div>

                    <!-- Description -->
                    <div class="form-group">
                        <label class="form-label" for="report-description">
                            Detailed Description <span style="color:var(--sev-critical)">*</span>
                        </label>
                        <textarea class="form-control" id="report-description" rows="5"
                            placeholder="Describe the issue in detail — location, duration, affected area, any safety concern, etc." required minlength="20"></textarea>
                        <span class="form-hint" id="char-count">0 / 2000 characters</span>
                    </div>

                    <!-- Image Upload -->
                    <div class="form-group">
                        <label class="form-label">Photo Evidence <span style="color:var(--text-3)">(optional)</span></label>
                        <div class="upload-zone" id="upload-zone">
                            <input type="file" id="image-input" name="image" accept="image/*">
                            <div class="upload-icon">📸</div>
                            <p class="upload-text"><strong>Click to upload</strong> or drag &amp; drop</p>
                            <p class="upload-hint">JPEG, PNG, WebP, GIF — max 5 MB</p>
                        </div>
                        <div class="image-preview-container" id="image-preview-container">
                            <div class="image-preview">
                                <img id="image-preview-img" src="" alt="Preview">
                                <button type="button" class="image-preview__remove" id="image-remove-btn" title="Remove image">✕</button>
                            </div>
                        </div>
                    </div>

                    <!-- ══ LOCATION SECTION ══════════════════ -->
                    <div class="form-group">
                        <label class="form-label">📍 Location <span style="color:var(--text-3)">(recommended)</span></label>

                        <!-- Location method tabs -->
                        <div class="location-methods">
                            <button type="button" class="loc-method-btn active" id="method-gps">
                                📡 Auto GPS
                            </button>
                            <button type="button" class="loc-method-btn" id="method-map">
                                🗺️ Pick on Map
                            </button>
                            <button type="button" class="loc-method-btn" id="method-manual">
                                ⌨️ Enter Manually
                            </button>
                        </div>

                        <!-- GPS method -->
                        <div id="loc-gps-panel">
                            <button type="button" class="location-btn" id="get-location-btn" style="width:100%;justify-content:center">
                                📍 Detect My Location
                            </button>
                        </div>

                        <!-- Map pin method -->
                        <div id="loc-map-panel" style="display:none">
                            <div class="map-selector-wrap" id="map-selector-wrap">
                                <div class="map-selector-header">
                                    <span class="map-selector-tip">🖱️ Click anywhere on the map to drop a pin</span>
                                    <span class="map-selector-coords" id="pin-coords-display"></span>
                                </div>
                                <div id="pin-map"></div>
                            </div>
                        </div>

                        <!-- Manual method -->
                        <div id="loc-manual-panel" style="display:none">
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
                                <div>
                                    <label class="form-label" for="lat-manual">Latitude</label>
                                    <input class="form-control" id="lat-manual" type="number" step="any" placeholder="-90 to 90">
                                </div>
                                <div>
                                    <label class="form-label" for="lng-manual">Longitude</label>
                                    <input class="form-control" id="lng-manual" type="number" step="any" placeholder="-180 to 180">
                                </div>
                            </div>
                            <button type="button" class="btn btn-secondary btn-sm" id="manual-confirm-btn" style="margin-top:.5rem">
                                Confirm Coordinates
                            </button>
                        </div>

                        <!-- Shared hidden fields (always submitted) -->
                        <input type="hidden" id="latitude" name="latitude">
                        <input type="hidden" id="longitude" name="longitude">
                        <input type="hidden" id="address" name="address">
                        <input type="hidden" id="zone" name="zone">

                        <!-- Geocoding state -->
                        <div class="geocoding-state" id="geocoding-state"></div>

                        <!-- Resolved address display -->
                        <div class="address-display" id="address-display">
                            <span class="address-display__icon">📍</span>
                            <span id="address-text"></span>
                        </div>
                    </div>

                    <!-- Landmark -->
                    <div class="form-group">
                        <label class="form-label" for="landmark-input">
                            🏛️ Nearest Landmark <span style="color:var(--text-3)">(optional)</span>
                        </label>
                        <input class="form-control" id="landmark-input" name="landmark" type="text"
                            placeholder="e.g. Near the Total filling station, opposite Unity School"
                            maxlength="255">
                        <span class="form-hint">Tag a recognisable nearby landmark to help locate this issue</span>
                    </div>

                    <!-- AI Notice -->
                    <div style="background:rgba(6,182,212,.08);border:1px solid rgba(6,182,212,.25);
                    border-radius:var(--radius-sm);padding:1rem;margin-bottom:1.5rem;font-size:.875rem;color:var(--text-2)">
                        🤖 <strong style="color:var(--accent)">AI Analysis:</strong>
                        After you submit, Gemini AI will classify this report, assign a severity score (0–100),
                        generate a summary, and recommend an action plan — all within seconds.
                    </div>

                    <!-- Submit -->
                    <button type="submit" class="btn btn-primary btn-lg btn-block" id="report-submit-btn" style="height:60px;font-size:1.1rem;letter-spacing:0.02em;box-shadow:var(--shadow-lg)">
                        🚀 Submit Report &amp; Analyse
                    </button>

                </form>
            </div>

            <!-- ════ AI PROCESSING STATE ══════════════ -->
            <div class="ai-processing" id="ai-processing-state">
                <div class="ai-processing__icon">🤖</div>
                <h3 class="ai-processing__title">Gemini AI is Analysing…</h3>
                <p class="ai-processing__status">Conducting deep analysis, calculating severity score, and generating recommendations.</p>
                <div style="margin-top:2rem; width:200px; height:4px; background:var(--surface-3); border-radius:99px; overflow:hidden; position:relative">
                    <div style="position:absolute; inset:0; background:var(--primary); width:40%; border-radius:99px; animation: skeleton-sweep 1.5s infinite"></div>
                </div>
            </div>

            <!-- ════ AI RESULT CARD ════════════════════ -->
            <div class="ai-result" id="ai-result">
                <div class="ai-result__header">
                    <div style="display:flex;align-items:center;gap:1.25rem">
                        <div style="width:54px;height:54px;background:linear-gradient(135deg, var(--primary), var(--accent));border-radius:14px;display:grid;place-items:center;font-size:1.6rem;color:#fff;box-shadow:var(--glow)">🤖</div>
                        <div>
                            <div style="font-size:1.35rem;font-weight:900;letter-spacing:-0.01em">AI Triage Complete</div>
                            <div style="font-size:0.85rem;color:var(--text-3);font-weight:600">Powered by Gemini 1.5 Flash</div>
                        </div>
                    </div>
                    <span class="badge badge-resolved" style="padding:0.4rem 0.9rem;font-size:0.8rem">✅ Processed</span>
                </div>

                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:2rem;padding-bottom:1.5rem;border-bottom:1px solid var(--border)">
                    <div id="ai-priority-badge"></div>
                    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:0.4rem">
                        <span id="ai-confidence-text" style="font-size:0.75rem;font-weight:700;color:var(--text-3);text-transform:uppercase;letter-spacing:0.05em">—</span>
                        <div style="width:120px;height:6px;background:var(--surface-3);border-radius:99px;overflow:hidden">
                            <div id="ai-confidence-bar-fill" style="height:100%;width:0%;border-radius:99px;transition:width 0.8s var(--ease-out)"></div>
                        </div>
                    </div>
                </div>

                <div class="ai-data-grid">
                    <div class="ai-data-item">
                        <div class="ai-data-item__label">AI Classification</div>
                        <div id="ai-category-result" style="margin-top:0.25rem"></div>
                    </div>
                    <div class="ai-data-item" style="border-left:1px solid var(--border);padding-left:1.5rem">
                        <div class="ai-data-item__label">Severity Analysis</div>
                        <div style="display:flex;align-items:baseline;gap:0.5rem">
                            <div id="ai-score" class="ai-data-item__score"></div>
                            <div id="ai-severity-label" class="ai-data-item__value"></div>
                        </div>
                        <div class="severity-bar">
                            <div class="severity-bar__fill" id="severity-bar-fill" style="width:0%"></div>
                        </div>
                    </div>
                </div>

                <div id="ai-smart-tags" style="display:flex;flex-wrap:wrap;gap:.5rem;margin-bottom:2rem"></div>

                <div class="ai-result__section">
                    <div class="ai-result__section-label"><span>📝</span> AI Summary & Context</div>
                    <div class="ai-result__section-text" id="ai-summary-text"></div>
                </div>

                <div class="ai-result__section">
                    <div class="ai-result__section-label"><span>🔧</span> Recommended Action Plan</div>
                    <div class="ai-result__section-text" id="ai-recommendation-text"></div>
                </div>

                <div class="ai-result__section" style="display:none">
                    <div class="ai-result__section-label"><span>🏛️</span> Responsible Department</div>
                    <div class="ai-result__section-text" id="ai-department-text"></div>
                </div>

                <div style="display:flex;gap:1rem;margin-top:2.5rem;flex-wrap:wrap">
                    <a href="dashboard.php" class="btn btn-primary btn-lg" style="flex:1;justify-content:center">📊 View Dashboard</a>
                    <button class="btn btn-secondary btn-lg" style="flex:1;justify-content:center" onclick="window.location.reload()">➕ New Report</button>
                </div>
            </div>

        </div><!-- /container -->
    </div><!-- /report-page -->

    <div id="toast-container"></div>

    <!-- Scripts -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="assets/js/utils.js"></script>
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/report.js"></script>
    <script>
        document.getElementById('hamburger').addEventListener('click', () => {
            document.getElementById('navbar-links').classList.toggle('open');
        });

        // ── Character count ────────────────────────────
        const descEl = document.getElementById('report-description');
        const countEl = document.getElementById('char-count');
        descEl?.addEventListener('input', () => {
            const len = descEl.value.length;
            countEl.textContent = `${len} / 2000 characters`;
            countEl.style.color = len >= 20 ? 'var(--sev-low)' : 'var(--text-3)';
        });

        // ── Location method switching ──────────────────
        let pinMap, pinMarker;
        const methods = ['gps', 'map', 'manual'];

        methods.forEach(m => {
            document.getElementById(`method-${m}`).addEventListener('click', () => {
                methods.forEach(x => {
                    document.getElementById(`method-${x}`).classList.toggle('active', x === m);
                    document.getElementById(`loc-${x}-panel`).style.display = x === m ? '' : 'none';
                });
                // Step indicator
                document.getElementById('step-2').classList.add('active');
                document.getElementById('step-1').classList.add('done');
                document.getElementById('step-1').classList.remove('active');

                // Init the pin map lazily
                if (m === 'map' && !pinMap) {
                    setTimeout(initPinMap, 100);
                }
            });
        });

        // ── Map pin selector ───────────────────────────
        function initPinMap() {
            const center = [6.4541, 3.3947]; // default: Lagos
            pinMap = L.map('pin-map', {
                zoomControl: true,
                center,
                zoom: 13
            });

            L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                attribution: '© OpenStreetMap contributors © CARTO',
                subdomains: 'abcd',
                maxZoom: 20,
            }).addTo(pinMap);

            const pinIcon = L.divIcon({
                html: `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 28 36">
                 <path d="M14 0C6.27 0 0 6.27 0 14c0 10.5 14 22 14 22S28 24.5 28 14C28 6.27 21.73 0 14 0z" fill="#6366f1" opacity="0.95"/>
                 <circle cx="14" cy="14" r="7" fill="white" opacity="0.3"/>
                 <circle cx="14" cy="14" r="4" fill="white"/>
               </svg>`,
                className: '',
                iconSize: [28, 36],
                iconAnchor: [14, 36],
                popupAnchor: [0, -36],
            });

            // Try to center on user's location first
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(pos => {
                    pinMap.setView([pos.coords.latitude, pos.coords.longitude], 15);
                }, () => {});
            }

            pinMap.on('click', e => {
                const {
                    lat,
                    lng
                } = e.latlng;
                if (pinMarker) pinMarker.remove();
                pinMarker = L.marker([lat, lng], {
                    icon: pinIcon
                }).addTo(pinMap);
                setCoordinates(lat, lng);
            });
        }

        // ── GPS detection ──────────────────────────────
        document.getElementById('get-location-btn')?.addEventListener('click', () => {
            const btn = document.getElementById('get-location-btn');
            if (!navigator.geolocation) {
                showToast('Geolocation is not supported by your browser.', 'error');
                return;
            }
            btn.innerHTML = '<span class="spinner"></span> Locating…';
            btn.disabled = true;

            navigator.geolocation.getCurrentPosition(
                pos => {
                    setCoordinates(pos.coords.latitude, pos.coords.longitude);
                    btn.innerHTML = '✅ Location Captured!';
                    btn.style.color = 'var(--sev-low)';
                    btn.style.borderColor = 'var(--sev-low)';
                    showToast('GPS location captured.', 'success');
                    setTimeout(() => {
                        btn.innerHTML = '📍 Refresh Location';
                        btn.disabled = false;
                    }, 2500);
                },
                err => {
                    showToast('Could not get location: ' + err.message, 'error');
                    btn.innerHTML = '📍 Try Again';
                    btn.disabled = false;
                }, {
                    enableHighAccuracy: true,
                    timeout: 10000
                }
            );
        });

        // ── Manual coordinate confirm ──────────────────
        document.getElementById('manual-confirm-btn')?.addEventListener('click', () => {
            const lat = parseFloat(document.getElementById('lat-manual').value);
            const lng = parseFloat(document.getElementById('lng-manual').value);
            if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                showToast('Please enter valid latitude (-90 to 90) and longitude (-180 to 180).', 'error');
                return;
            }
            setCoordinates(lat, lng);
            showToast('Coordinates confirmed.', 'success');
        });

        // ── Set coordinates + trigger reverse geocoding ─
        let geocodeTimer;

        function setCoordinates(lat, lng) {
            document.getElementById('latitude').value = lat.toFixed(7);
            document.getElementById('longitude').value = lng.toFixed(7);

            // Update map pin coords display
            const disp = document.getElementById('pin-coords-display');
            if (disp) disp.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;

            // Debounced reverse geocode
            clearTimeout(geocodeTimer);
            geocodeTimer = setTimeout(() => reverseGeocode(lat, lng), 600);
        }

        // ── Reverse geocoding via OpenStreetMap Nominatim ─
        async function reverseGeocode(lat, lng) {
            const stateEl = document.getElementById('geocoding-state');
            const addrDisp = document.getElementById('address-display');
            const addrText = document.getElementById('address-text');

            stateEl.innerHTML = `
                <span class="spinner" style="width:12px;height:12px;border-width:2px"></span> 
                Looking up address…`;

            try {
                const res = await fetch(
                    `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1`, {
                        headers: {
                            'Accept-Language': 'en',
                            'User-Agent': 'CivicShieldAI/1.0 (civic-issue-reporting)'
                        }
                    }
                );
                const data = await res.json();

                if (data && data.display_name) {
                    const addr = data.address || {};
                    const zone = addr.suburb || addr.neighbourhood || addr.city_district || addr.county || '';
                    const full = data.display_name;

                    document.getElementById('address').value = full;
                    document.getElementById('zone').value = zone;

                    addrText.textContent = full;
                    addrDisp.classList.add('visible');
                    stateEl.innerHTML = `<span style="color:var(--sev-low)">✅ Address resolved</span>
                                  ${zone ? `<span style="color:var(--text-3);margin-left:.5rem">Zone: <strong style="color:var(--accent)">${zone}</strong></span>` : ''}`;
                } else {
                    stateEl.innerHTML = '<span style="color:var(--text-3)">⚠️ Could not resolve address</span>';
                }
            } catch (e) {
                stateEl.innerHTML = '<span style="color:var(--text-3)">⚠️ Geocoding unavailable</span>';
            }
        }
    </script>
</body>

</html>