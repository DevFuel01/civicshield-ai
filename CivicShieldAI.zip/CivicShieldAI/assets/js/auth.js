// ============================================================
//  CivicShield AI — Auth Modal (Login / Register)
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    initAuthUI();
    updateNavForSession();
});

/* ─── Build modal HTML once if not already present ── */
function initAuthUI() {
    if (document.getElementById('auth-modal-overlay')) return;

    document.body.insertAdjacentHTML('beforeend', `
    <div class="modal-overlay" id="auth-modal-overlay" role="dialog" aria-modal="true">
      <div class="modal" style="max-width:420px">
        <button class="modal__close" id="auth-modal-close" aria-label="Close">&times;</button>

        <!-- Login View -->
        <div id="auth-view-login">
          <h2 class="modal__title">Welcome back 👋</h2>
          <form id="login-form" novalidate>
            <div class="form-group">
              <label class="form-label" for="login-email">Email</label>
              <input class="form-control" id="login-email" type="email" autocomplete="email" placeholder="you@example.com" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="login-password">Password</label>
              <input class="form-control" id="login-password" type="password" autocomplete="current-password" placeholder="••••••••" required>
            </div>
            <p id="login-error" class="form-error" style="display:none"></p>
            <button class="btn btn-primary btn-block btn-lg" type="submit" id="login-submit">
              Sign In
            </button>
          </form>
          <p style="text-align:center;margin-top:1.25rem;font-size:.875rem;color:var(--text-2)">
            Don't have an account?
            <button class="btn btn-outline btn-sm" id="switch-to-register" style="margin-left:.5rem">Create one</button>
          </p>
        </div>

        <!-- Register View -->
        <div id="auth-view-register" style="display:none">
          <h2 class="modal__title">Join CivicShield 🌍</h2>
          <form id="register-form" novalidate>
            <div class="form-group">
              <label class="form-label" for="reg-name">Full Name</label>
              <input class="form-control" id="reg-name" type="text" autocomplete="name" placeholder="Jane Smith" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="reg-email">Email</label>
              <input class="form-control" id="reg-email" type="email" autocomplete="email" placeholder="you@example.com" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="reg-password">Password <span class="form-hint" style="display:inline">(min 6 chars)</span></label>
              <input class="form-control" id="reg-password" type="password" autocomplete="new-password" placeholder="••••••••" required minlength="6">
            </div>
            <p id="reg-error" class="form-error" style="display:none"></p>
            <button class="btn btn-primary btn-block btn-lg" type="submit" id="reg-submit">
              Create Account
            </button>
          </form>
          <p style="text-align:center;margin-top:1.25rem;font-size:.875rem;color:var(--text-2)">
            Already have an account?
            <button class="btn btn-outline btn-sm" id="switch-to-login" style="margin-left:.5rem">Sign in</button>
          </p>
        </div>
      </div>
    </div>`);

    // Wire events
    document.getElementById('auth-modal-close').addEventListener('click', closeAuthModal);
    document.getElementById('auth-modal-overlay').addEventListener('click', e => {
        if (e.target === e.currentTarget) closeAuthModal();
    });
    document.getElementById('switch-to-register').addEventListener('click', () => showAuthView('register'));
    document.getElementById('switch-to-login').addEventListener('click', () => showAuthView('login'));
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    document.getElementById('register-form').addEventListener('submit', handleRegister);

    // Expose open triggers
    document.querySelectorAll('[data-auth-open]').forEach(btn => {
        btn.addEventListener('click', () => {
            const view = btn.dataset.authOpen || 'login';
            openAuthModal(view);
        });
    });

    document.querySelectorAll('[data-logout]').forEach(btn => {
        btn.addEventListener('click', handleLogout);
    });
}

/* ─── Modal control ──────────────────────────────── */
function openAuthModal(view = 'login') {
    showAuthView(view);
    document.getElementById('auth-modal-overlay').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeAuthModal() {
    document.getElementById('auth-modal-overlay').classList.remove('active');
    document.body.style.overflow = '';
}

function showAuthView(view) {
    document.getElementById('auth-view-login').style.display    = view === 'login'    ? '' : 'none';
    document.getElementById('auth-view-register').style.display = view === 'register' ? '' : 'none';
}

/* ─── Login ──────────────────────────────────────── */
async function handleLogin(e) {
    e.preventDefault();
    const errorEl = document.getElementById('login-error');
    const btn     = document.getElementById('login-submit');
    errorEl.style.display = 'none';
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Signing in…';

    try {
        const data = await apiFetch('api/auth.php?action=login', {
            method: 'POST',
            body: JSON.stringify({
                email:    document.getElementById('login-email').value.trim(),
                password: document.getElementById('login-password').value,
            }),
        });
        sessionStorage.setItem('csrf_token', data.csrf_token);
        sessionStorage.setItem('user', JSON.stringify(data.user));
        _sessionUser = data.user;
        showToast('Welcome back, ' + data.user.name + '! 🎉', 'success');
        closeAuthModal();
        updateNavForSession(data.user);
        // If on index, redirect to dashboard
        setTimeout(() => { window.location.reload(); }, 600);
    } catch (err) {
        errorEl.textContent = err.message;
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'Sign In';
    }
}

/* ─── Register ───────────────────────────────────── */
async function handleRegister(e) {
    e.preventDefault();
    const errorEl = document.getElementById('reg-error');
    const btn     = document.getElementById('reg-submit');
    errorEl.style.display = 'none';
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Creating account…';

    try {
        const data = await apiFetch('api/auth.php?action=register', {
            method: 'POST',
            body: JSON.stringify({
                name:     document.getElementById('reg-name').value.trim(),
                email:    document.getElementById('reg-email').value.trim(),
                password: document.getElementById('reg-password').value,
            }),
        });
        sessionStorage.setItem('csrf_token', data.csrf_token);
        sessionStorage.setItem('user', JSON.stringify(data.user));
        _sessionUser = data.user;
        showToast('Account created! Welcome aboard 🚀', 'success');
        closeAuthModal();
        updateNavForSession(data.user);
        setTimeout(() => { window.location.reload(); }, 600);
    } catch (err) {
        errorEl.textContent = err.message;
        errorEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'Create Account';
    }
}

/* ─── Logout ─────────────────────────────────────── */
async function handleLogout() {
    try {
        await apiFetch('api/auth.php?action=logout', { method: 'POST' });
    } finally {
        clearSession();
        showToast('Logged out successfully.', 'info');
        setTimeout(() => { window.location.href = `${BASE}/index.php`; }, 500);
    }
}

/* ─── Update navbar links based on auth state ────── */
async function updateNavForSession(user) {
    user = user || (await getSessionUser());
    const navAuth    = document.getElementById('nav-auth-buttons');
    const navUser    = document.getElementById('nav-user-info');
    const navUserName = document.getElementById('nav-user-name');

    if (!navAuth && !navUser) return; // No nav elements on this page

    if (user) {
        if (navAuth)     navAuth.style.display    = 'none';
        if (navUser)     navUser.style.display     = 'flex';
        if (navUserName) navUserName.textContent   = user.name;
    } else {
        if (navAuth)     navAuth.style.display     = 'flex';
        if (navUser)     navUser.style.display     = 'none';
    }
}

// Expose globally for inline onclick attributes in PHP
window.openAuthModal = openAuthModal;
window.handleLogout  = handleLogout;
