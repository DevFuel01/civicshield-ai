// ============================================================
//  CivicShield AI — Utility Helpers
// ============================================================

/* ─── API base URL ───────────────────────────────── */
const BASE = window.location.origin + '/CivicShieldAI';

/* ─── Session user (cached) ──────────────────────── */
let _sessionUser = null;

/**
 * Wrapper around fetch that:
 * - Prefixes the URL with BASE when a relative path is given
 * - Attaches the CSRF token header automatically
 * - Returns the parsed JSON (or throws with {error} payload)
 */
async function apiFetch(url, options = {}) {
    const fullUrl = url.startsWith('http') ? url : `${BASE}/${url}`;
    const csrfToken = sessionStorage.getItem('csrf_token') || '';

    const defaultHeaders = {
        'X-CSRF-Token': csrfToken,
    };

    // Don't set Content-Type for FormData (browser sets it automatically with boundary)
    if (!(options.body instanceof FormData)) {
        defaultHeaders['Content-Type'] = 'application/json';
    }

    const res = await fetch(fullUrl, {
        ...options,
        headers: { ...defaultHeaders, ...(options.headers || {}) },
        credentials: 'same-origin',
    });

    // CSV export: return raw response
    if (res.headers.get('Content-Type')?.includes('text/csv')) {
        return res;
    }

    const data = await res.json();
    if (!res.ok) {
        throw new Error(data.error || `HTTP ${res.status}`);
    }
    return data;
}

/* ─── Toast Notifications ────────────────────────── */
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const icons = { 
        success: '<span class="toast-icon">✨</span>', 
        error:   '<span class="toast-icon">❗</span>', 
        info:    '<span class="toast-icon">💠</span>', 
        warning: '<span class="toast-icon">⚠️</span>' 
    };
    
    const toast = document.createElement('div');
    toast.className = `toast toast--${type} animate-slide-in-right`;
    toast.innerHTML = `
        ${icons[type] || icons.info}
        <div class="toast-content">${message}</div>
        <div class="toast-progress"></div>
    `;
    container.appendChild(toast);

    // Auto-remove after animation
    setTimeout(() => {
        toast.classList.add('animate-fade-out');
        setTimeout(() => toast.remove(), 400);
    }, 4000);
}

/* ─── Format date string ─────────────────────────── */
function formatDate(dateStr) {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatDateTime(dateStr) {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    return d.toLocaleString('en-GB', {
        day: '2-digit', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit',
    });
}

/* ─── Severity helpers ───────────────────────────── */
function getSeverityClass(score) {
    score = parseInt(score, 10);
    if (isNaN(score)) return '';
    if (score <= 30) return 'sev-low';
    if (score <= 60) return 'sev-medium';
    if (score <= 80) return 'sev-high';
    return 'sev-critical';
}

function getSeverityLabel(score) {
    score = parseInt(score, 10);
    if (isNaN(score)) return 'Unscored';
    if (score <= 30)  return 'Low';
    if (score <= 60)  return 'Moderate';
    if (score <= 80)  return 'High';
    return 'Critical';
}

function getSeverityColor(score) {
    score = parseInt(score, 10);
    if (isNaN(score)) return '#64748b'; // var(--text-3)
    if (score <= 30)  return '#10b981'; // var(--sev-low)
    if (score <= 60)  return '#f59e0b'; // var(--sev-medium)
    if (score <= 80)  return '#f97316'; // var(--sev-high)
    return '#ef4444'; // var(--sev-critical)
}

function getSeverityMarkerColor(score) {
    score = parseInt(score, 10);
    if (isNaN(score)) return 'gray';
    if (score <= 30)  return 'green';
    if (score <= 60)  return 'yellow';
    if (score <= 80)  return 'orange';
    return 'red';
}

/* ─── Status badge HTML ──────────────────────────── */
function statusBadge(status) {
    const map = {
        'pending':     ['badge-pending',  '⏳'],
        'in-progress': ['badge-progress', '🔄'],
        'resolved':    ['badge-resolved', '✅'],
    };
    const [cls, icon] = map[status] || ['', ''];
    return `<span class="badge ${cls}">${icon} ${status}</span>`;
}

/* ─── Category badge HTML ─────────────────────────── */
function categoryBadge(cat) {
    if (!cat) return '<span class="badge badge-other">Unclassified</span>';
    const cls = cat.replace(/\s+/g, '-').toLowerCase();
    const icons = {
        pothole: '🕳️', electrical: '⚡', flooding: '🌊',
        waste: '🗑️', 'structural-damage': '🏗️', other: '📌',
    };
    return `<span class="badge badge-${cls}">${icons[cls] || '📌'} ${cat}</span>`;
}

/* ─── Session helpers ─────────────────────────────── */
async function getSessionUser() {
    if (_sessionUser !== null) return _sessionUser;
    try {
        const data = await apiFetch('api/auth.php?action=me');
        // Always save the CSRF token, even for guests
        if (data.csrf_token) {
            sessionStorage.setItem('csrf_token', data.csrf_token);
        }
        
        if (data.authenticated) {
            _sessionUser = data.user;
            sessionStorage.setItem('user', JSON.stringify(data.user));
        } else {
            _sessionUser = null;
            sessionStorage.removeItem('user');
        }
    } catch {
        _sessionUser = null;
    }
    return _sessionUser;
}

function clearSession() {
    _sessionUser = null;
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('csrf_token');
}

/* ─── Redirect if not authed ─────────────────────── */
async function requireLogin(redirectTo = 'index.php') {
    const user = await getSessionUser();
    if (!user) {
        showToast('Please log in to continue.', 'warning');
        setTimeout(() => { window.location.href = `${BASE}/${redirectTo}`; }, 1200);
        return null;
    }
    return user;
}

/* ─── Humanize numbers ────────────────────────────── */
function humanizeNumber(n) {
    n = parseInt(n, 10);
    if (isNaN(n)) return '—';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
    return n.toString();
}

/* ─── Debounce ────────────────────────────────────── */
function debounce(fn, ms = 300) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/* ─── Download CSV blob ───────────────────────────── */
async function downloadCsv() {
    try {
        const res = await apiFetch('api/analytics.php?type=export');
        const blob = await res.blob();
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href = url;
        a.download = `civicshield_export_${new Date().toISOString().slice(0,10)}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    } catch (e) {
        showToast('Export failed: ' + e.message, 'error');
    }
}
/**
 * Escape HTML for safety
 */
function escapeHtml(str) {
    if (!str) return '';
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return str.replace(/[&<>"']/g, m => map[m]);
}

// Expose for globally
window.escapeHtml = escapeHtml;
