// ============================================================
//  CivicShield AI — Dashboard Logic (Charts, Map, Polling)
// ============================================================

let _pieChart, _lineChart, _barChart;
let _dashboardMap, _pollTimer;
let _reports = [];
let _currentPage = 1;
const _pageSize = 20;
let _currentFilter = { status: '', category: '', severityRange: '', zone: '', dateFrom: '', dateTo: '', sort: 'recent', bounds: null };

document.addEventListener('DOMContentLoaded', async () => {
    const user = await getSessionUser();
    if (!user) {
        window.location.href = `${BASE}/index.php`;
        return;
    }

    // Show admin controls if admin
    document.querySelectorAll('.admin-only').forEach(el => {
        el.style.display = user.role === 'admin' ? '' : 'none';
    });

    // Update user display
    const nameEl = document.getElementById('dash-user-name');
    if (nameEl) nameEl.textContent = user.name;

    // Initialize map
    _dashboardMap = initMap('dashboard-map', { center: [6.4541, 3.3947], zoom: 12 });

    // Map-based search logic
    const mapSearchBtn = document.getElementById('map-search-btn');
    _dashboardMap.on('moveend', () => {
        if (mapSearchBtn) mapSearchBtn.style.display = 'block';
    });

    mapSearchBtn?.addEventListener('click', () => {
        const bounds = _dashboardMap.getBounds();
        _currentFilter.bounds = {
            sw_lat: bounds.getSouthWest().lat,
            sw_lng: bounds.getSouthWest().lng,
            ne_lat: bounds.getNorthEast().lat,
            ne_lng: bounds.getNorthEast().lng
        };
        loadReports();
        mapSearchBtn.style.display = 'none';
        showToast('Filtering by map area', 'info');
    });

    // Heatmap toggle button
    let _heatmapActive = false;
    document.getElementById('heatmap-toggle-btn')?.addEventListener('click', e => {
        _heatmapActive = toggleHeatmap(_dashboardMap, !_heatmapActive);
        const btn = e.currentTarget;
        btn.classList.toggle('btn-primary',   _heatmapActive);
        btn.classList.toggle('btn-secondary', !_heatmapActive);
        btn.innerHTML = _heatmapActive ? '🔥 Heatmap ON' : '🔥 Heatmap';
        showToast(_heatmapActive ? 'Heatmap mode enabled' : 'Marker mode restored', 'info');
    });

    // Load data
    await loadReports();
    await Promise.all([loadStats(), loadCharts(), loadPredictiveWatchlist()]);

    // CSV export button
    document.getElementById('export-csv-btn')?.addEventListener('click', downloadCsv);

    // Filter controls — Updated to use server-side loading
    document.getElementById('filter-status')?.addEventListener('change', e => {
        _currentFilter.status = e.target.value;
        loadReports();
    });
    document.getElementById('filter-category')?.addEventListener('change', e => {
        _currentFilter.category = e.target.value;
        loadReports();
    });
    document.getElementById('search-reports')?.addEventListener('input', debounce(() => {
        loadReports();
    }, 300));

    // New filters
    document.getElementById('filter-severity')?.addEventListener('change', e => {
        _currentFilter.severityRange = e.target.value;
        loadReports();
    });
    document.getElementById('filter-zone')?.addEventListener('input', debounce(() => {
        _currentFilter.zone = document.getElementById('filter-zone').value.trim().toLowerCase();
        loadReports();
    }, 300));
    document.getElementById('filter-date-from')?.addEventListener('change', e => {
        _currentFilter.dateFrom = e.target.value;
        loadReports();
    });
    document.getElementById('filter-date-to')?.addEventListener('change', e => {
        _currentFilter.dateTo = e.target.value;
        loadReports();
    });

    document.getElementById('filter-sort')?.addEventListener('change', e => {
        _currentFilter.sort = e.target.value;
        loadReports(); // Reload from API for server-side sorting
    });

    // Load More button
    document.getElementById('load-more-btn')?.addEventListener('click', () => {
        _currentPage++;
        loadReports(true);
    });

    // Clear all filters
    document.getElementById('clear-filters-btn')?.addEventListener('click', () => {
        _currentFilter = { status:'', category:'', severityRange:'', zone:'', dateFrom:'', dateTo:'', sort:'recent', bounds: null };
        ['filter-status','filter-category','filter-severity','filter-zone',
         'filter-date-from','filter-date-to','search-reports','filter-sort'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = (id === 'filter-sort' ? 'recent' : '');
        });
        loadReports();
    });

    // Sidebar navigation
    document.querySelectorAll('.sidebar__nav-item[data-section]').forEach(btn => {
        btn.addEventListener('click', () => {
            const section = btn.dataset.section;
            showSection(section);
            document.querySelectorAll('.sidebar__nav-item').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    // Mobile sidebar toggle
    document.getElementById('sidebar-toggle')?.addEventListener('click', () => {
        document.getElementById('dashboard-sidebar').classList.toggle('open');
    });

    // Auto-refresh every 30 seconds
    _pollTimer = setInterval(async () => {
        await Promise.all([loadStats(), loadReports()]);
        updateLiveBadge();
    }, 30000);

    updateLiveBadge();
});

/* ─── Show/hide dashboard sections ───────────────── */
function showSection(id) {
    document.querySelectorAll('.dash-section').forEach(s => {
        s.style.display = s.id === `section-${id}` ? '' : 'none';
    });

    // Re-render charts when charts section becomes visible (fixes canvas sizing)
    if (id === 'analytics') {
        _pieChart?.resize();
        _lineChart?.resize();
        _barChart?.resize();
    }
    if (id === 'map') {
        setTimeout(() => _dashboardMap?.invalidateSize(), 100);
    }
}

/* ─── Load stats ─────────────────────────────────── */
async function loadStats() {
    try {
        const data = await apiFetch('api/analytics.php?type=stats');
        setStatValue('stat-total',      data.total       ?? '—');
        setStatValue('stat-pending',    data.pending      ?? '—');
        setStatValue('stat-progress',   data.in_progress  ?? '—');
        setStatValue('stat-resolved',   data.resolved     ?? '—');
        setStatValue('stat-avg-sev',    data.avg_severity ?? '—');
    } catch (e) {
        console.warn('Stats load failed', e);
    }
}

function setStatValue(id, val) {
    const el = document.getElementById(id);
    if (el) {
        el.textContent = val;
        el.classList.add('animate-fade-in');
    }
}

/* ─── Load charts ─────────────────────────────────── */
async function loadCharts() {
    try {
        const [categories, timeline, severity] = await Promise.all([
            apiFetch('api/analytics.php?type=categories'),
            apiFetch('api/analytics.php?type=timeline&days=30'),
            apiFetch('api/analytics.php?type=severity'),
        ]);

        renderPieChart(categories);
        renderLineChart(timeline);
        renderBarChart(severity);
    } catch (e) {
        console.warn('Charts load failed', e);
    }
}

const CHART_COLORS = [
    '#f97316','#eab308','#06b6d4','#22c55e','#ef4444','#8b5cf6',
];

function chartDefaults(type) {
    Chart.defaults.color = '#9ca3af';
    Chart.defaults.font.family = 'Inter, sans-serif';
    Chart.defaults.font.size = 12;
}

function renderPieChart(data) {
    const ctx = document.getElementById('pie-chart')?.getContext('2d');
    if (!ctx) return;
    if (_pieChart) _pieChart.destroy();
    chartDefaults();

    _pieChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(d => d.label),
            datasets: [{
                data:            data.map(d => d.value),
                backgroundColor: CHART_COLORS.slice(0, data.length),
                borderColor:     'transparent',
                borderWidth:     2,
                hoverOffset:     8,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { padding: 14, usePointStyle: true } },
                tooltip: {
                    callbacks: {
                        label: ctx => ` ${ctx.label}: ${ctx.parsed} reports`,
                    },
                },
            },
            cutout: '65%',
            animation: { animateRotate: true, duration: 800 },
        },
    });
}

function renderLineChart(data) {
    const ctx = document.getElementById('line-chart')?.getContext('2d');
    if (!ctx) return;
    if (_lineChart) _lineChart.destroy();
    chartDefaults();

    const gradient = ctx.createLinearGradient(0, 0, 0, 280);
    gradient.addColorStop(0, 'rgba(99,102,241,0.4)');
    gradient.addColorStop(1, 'rgba(99,102,241,0)');

    _lineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => d.date),
            datasets: [{
                label:           'Reports',
                data:            data.map(d => d.count),
                borderColor:     '#6366f1',
                backgroundColor: gradient,
                borderWidth:     2,
                pointBackgroundColor: '#6366f1',
                pointRadius:     4,
                pointHoverRadius: 6,
                fill:            true,
                tension:         0.35,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    ticks: { maxRotation: 45, autoSkip: true, maxTicksLimit: 8 },
                },
                y: {
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    beginAtZero: true,
                    ticks: { stepSize: 1 },
                },
            },
        },
    });
}

function renderBarChart(data) {
    const ctx = document.getElementById('bar-chart')?.getContext('2d');
    if (!ctx) return;
    if (_barChart) _barChart.destroy();
    chartDefaults();

    const colorsForSeverity = {
        'Low (0-30)':       '#22c55e',
        'Moderate (31-60)': '#eab308',
        'High (61-80)':     '#f97316',
        'Critical (81-100)':'#ef4444',
        'Unscored':         '#6b7280',
    };

    _barChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.label),
            datasets: [{
                label: 'Reports',
                data:  data.map(d => d.count),
                backgroundColor: data.map(d => colorsForSeverity[d.label] || '#6b7280'),
                borderRadius: 6,
                borderSkipped: false,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: 'rgba(255,255,255,0.05)' } },
                y: { grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true, ticks: { stepSize: 1 } },
            },
        },
    });
}

/* ─── Load & render reports ───────────────────────── */
async function loadReports(isLoadMore = false) {
    if (!isLoadMore) {
        _currentPage = 1;
    }

    const loadMoreBtn = document.getElementById('load-more-btn');
    if (loadMoreBtn && isLoadMore) {
        loadMoreBtn.disabled = true;
        loadMoreBtn.innerHTML = '<span class="spinner"></span> Loading…';
    }

    try {
        const params = new URLSearchParams();
        params.append('page', _currentPage);
        params.append('limit', _pageSize);
        params.append('status', _currentFilter.status);
        params.append('category', _currentFilter.category);
        params.append('sort', _currentFilter.sort);
        params.append('zone', _currentFilter.zone);
        params.append('search', document.getElementById('search-reports')?.value || '');
        
        if (_currentFilter.severityRange) {
            const [min, max] = _currentFilter.severityRange.split(',');
            params.append('severity_min', min);
            params.append('severity_max', max);
        }
        if (_currentFilter.dateFrom) params.append('date_from', _currentFilter.dateFrom);
        if (_currentFilter.dateTo)   params.append('date_to',   _currentFilter.dateTo);

        if (_currentFilter.bounds) {
            params.append('sw_lat', _currentFilter.bounds.sw_lat);
            params.append('sw_lng', _currentFilter.bounds.sw_lng);
            params.append('ne_lat', _currentFilter.bounds.ne_lat);
            params.append('ne_lng', _currentFilter.bounds.ne_lng);
        }

        const data = await apiFetch(`api/report.php?${params.toString()}`);
        
        if (isLoadMore) {
            _reports = _reports.concat(data);
        } else {
            _reports = data;
        }

        if (loadMoreBtn) {
            loadMoreBtn.disabled = false;
            loadMoreBtn.innerHTML = '🔄 Load More Reports';
            loadMoreBtn.style.display = data.length < _pageSize ? 'none' : 'inline-block';
        }

        loadMarkers(_dashboardMap, _reports);
        renderReportsTable(isLoadMore);
    } catch (e) {
        console.warn('Reports load failed', e);
        if (loadMoreBtn) loadMoreBtn.style.display = 'none';
    }
}

function renderReportsTable(isLoadMore = false) {
    try {
        const tbody    = document.getElementById('reports-tbody');
        const tbody2   = document.getElementById('all-reports-tbody');
        if (!tbody && !tbody2) return;

        // Note: Filtering is now mostly done on the server.
        // We only use the current reports array which is already paginated/filtered.
        const reportsToRender = isLoadMore ? _reports.slice(-_pageSize) : _reports;

        if (!isLoadMore) {
            if (tbody)  tbody.innerHTML = '';
            if (tbody2) tbody2.innerHTML = '';
        }

        const user    = JSON.parse(sessionStorage.getItem('user') || '{}');
        const isAdmin = user.role === 'admin';

        // Helper: render a single row
        const renderRow = (r, showNotes = false) => {
            const score  = r.ai_severity_score ?? null;
            const color  = getSeverityColor(score);
            const scoreDisplay = score !== null ? `
              <div class="severity-indicator">
                <span class="severity-dot" style="background:${color}"></span>
                <span style="color:${color}">${score}</span>
              </div>` : '<span style="color:var(--text-3)">—</span>';

            const rank = parseInt(r.intelligent_score) || 0;
            const rankColor = rank > 80 ? 'var(--sev-critical)' : rank > 50 ? 'var(--sev-high)' : 'var(--text-3)';
            const pulseClass = rank > 70 ? 'pulse-urgent' : '';
            const urgencyDisplay = `
                <div class="urgency-badge ${pulseClass}" style="color:${rankColor}; font-weight:800; font-size:0.85rem; display:flex; align-items:center; gap:4px">
                    ${rank > 70 ? '⚡' : ''} ${rank}
                </div>
            `;

            const statusControl = isAdmin
                ? `<div style="display:flex;flex-direction:column;gap:6px">
                    <select class="status-select" data-id="${r.id}" onchange="updateStatus(this)">
                        <option value="pending"     ${r.status==='pending'    ?'selected':''}>⏳ Pending</option>
                        <option value="in-progress" ${r.status==='in-progress'?'selected':''}>🔄 In Progress</option>
                        <option value="resolved"    ${r.status==='resolved'   ?'selected':''}>✅ Resolved</option>
                    </select>
                    <input type="text" data-msg-id="${r.id}" placeholder="Timeline message..." 
                           style="background:var(--surface-2); color:var(--text-2); border:1px solid var(--border); 
                                  border-radius:6px; padding:4px 8px; font-size:0.75rem; width:100%">
                   </div>`
                : statusBadge(r.status);

            const notesCell = (isAdmin && showNotes)
                ? `<td class="admin-only">
                    <div style="display:flex;flex-direction:column;gap:4px;min-width:140px">
                      <textarea data-notes-id="${r.id}" rows="2"
                        style="background:var(--surface-2);color:var(--text-1);
                                border:1px solid var(--border);border-radius:6px;
                                padding:4px 6px;font-size:.75rem;resize:vertical;width:100%"
                        placeholder="Admin notes…">${window.escapeHtml(r.admin_notes || '')}</textarea>
                      <button class="btn btn-sm btn-secondary" style="font-size:.7rem"
                        onclick="saveAdminNotes(${r.id}, this)">💾 Save</button>
                    </div>
                  </td>`
                : (showNotes ? '<td class="admin-only"></td>' : '');

            const mapBtn = `<button class="btn btn-sm btn-secondary"
                  onclick="focusMapMarker(${r.latitude}, ${r.longitude})"
                  title="View on map" ${!r.latitude ? 'disabled' : ''}>🗺️</button>`;

            return `<tr>
              <td><strong>${window.escapeHtml(r.title)}</strong>
                  <div style="font-size:.75rem;color:var(--text-3)">${formatDate(r.created_at)}</div>
              </td>
              <td>${categoryBadge(r.ai_category)}</td>
              <td>${scoreDisplay}</td>
              <td>${urgencyDisplay}</td>
              <td>${statusControl}</td>
              <td style="font-size:.8rem;color:var(--text-2)">${window.escapeHtml(r.reporter_name || '—')}</td>
              ${notesCell}
              <td>${mapBtn}</td>
            </tr>`;
        };

        // 1. Overview: Top 10 High-Risk
        if (tbody && !isLoadMore) {
            const top10 = [..._reports].sort((a,b) => (parseInt(b.ai_severity_score) || 0) - (parseInt(a.ai_severity_score) || 0)).slice(0, 10);
            tbody.innerHTML = top10.length === 0
                ? `<tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--text-3)">No reports match.</td></tr>`
                : top10.map(r => renderRow(r, false)).join('');
        }

        // 2. All Reports: Full list with appending for Load More
        if (tbody2) {
            const html = reportsToRender.map(r => renderRow(r, true)).join('');
            if (isLoadMore) {
                const temp = document.createElement('tbody');
                temp.innerHTML = html;
                while (temp.firstChild) tbody2.appendChild(temp.firstChild);
            } else {
                tbody2.innerHTML = html || `<tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--text-3)">No reports found.</td></tr>`;
            }
        }
    } catch (e) {
        console.error('renderReportsTable failed:', e);
        showToast('Error rendering tables: ' + e.message, 'error');
    }
}

/* ─── Admin: Update status ───────────────────────── */
async function updateStatus(selectEl) {
    const id     = selectEl.dataset.id;
    const status = selectEl.value;
    const msgEl  = document.querySelector(`input[data-msg-id="${id}"]`);
    const timeline_message = msgEl ? msgEl.value.trim() : null;

    try {
        await apiFetch(`api/report.php?id=${id}`, {
            method: 'PATCH',
            body:   JSON.stringify({ 
                status: status,
                timeline_message: timeline_message
            }),
        });
        showToast(`Status updated to "${status}".`, 'success');
        if (msgEl) msgEl.value = ''; // Clear message after success
        
        // Sync in local array
        const rep = _reports.find(r => r.id == id);
        if (rep) { rep.status = status; }
    } catch (e) {
        showToast('Failed to update: ' + e.message, 'error');
        selectEl.value = _reports.find(r => r.id == id)?.status || 'pending';
    }
}

/* ─── Admin: Save notes ───────────────── */
async function saveAdminNotes(id, btn) {
    const textarea = document.querySelector(`textarea[data-notes-id="${id}"]`);
    if (!textarea) return;
    const notes = textarea.value;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>';
    try {
        await apiFetch(`api/report.php?id=${id}`, {
            method: 'PATCH',
            body:   JSON.stringify({ admin_notes: notes }),
        });
        const rep = _reports.find(r => r.id == id);
        if (rep) rep.admin_notes = notes;
        showToast('Notes saved.', 'success');
    } catch (e) {
        showToast('Failed to save notes: ' + e.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '💾 Save';
    }
}

/* ─── Summary CSV export ─────────────── */
async function downloadSummaryCsv() {
    window.location.href = `${BASE}/api/analytics.php?type=summary_export`;
}

/* ─── Focus map on marker ─────────────────────────── */
function focusMapMarker(lat, lng) {
    if (!lat || !lng) return;
    showSection('map');
    document.querySelector('[data-section="map"]')?.click();
    setTimeout(() => {
        _dashboardMap.setView([parseFloat(lat), parseFloat(lng)], 16);
    }, 150);
}

/* ─── Live badge ─────────────────────────────────── */
function updateLiveBadge() {
    const badge = document.getElementById('live-time');
    if (badge) badge.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
}

/* ─── 🔮 Predictive Risk Simulation ───────────────── */
async function loadPredictiveWatchlist() {
    const watchlistEl = document.getElementById('predictive-watchlist');
    if (!watchlistEl) return;

    try {
        const data = await apiFetch('api/analytics.php?type=predictive');
        if (!data || data.length === 0) {
            watchlistEl.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:var(--text-3);padding:1rem">No significant regional risks detected yet.</div>';
            return;
        }

        watchlistEl.innerHTML = data.map(z => {
            const trendIcon = z.trend === 'escalating' ? '📈' : (z.trend === 'stabilizing' ? '📉' : '➡️');
            const trendColor = z.trend === 'escalating' ? 'var(--sev-critical)' : (z.trend === 'stabilizing' ? 'var(--sev-low)' : 'var(--text-3)');
            const riskBg = z.risk_level === 'Critical' ? 'rgba(239, 68, 68, 0.08)' : (z.risk_level === 'High' ? 'rgba(249, 115, 22, 0.05)' : 'rgba(255,255,255,0.02)');
            const riskBorder = z.risk_level === 'Critical' ? 'rgba(239, 68, 68, 0.3)' : (z.risk_level === 'High' ? 'rgba(249, 115, 22, 0.3)' : 'var(--border)');

            return `
                <div class="watchlist-card" style="background:${riskBg}; border:1px solid ${riskBorder}; border-radius:12px; padding:1.25rem; position:relative; overflow:hidden">
                    <div style="font-size:0.65rem; text-transform:uppercase; letter-spacing:0.1em; color:var(--text-3); margin-bottom:0.25rem; font-weight:700">${z.risk_level} Risk Zone</div>
                    <div style="font-weight:700; font-size:1.15rem; color:var(--text-1); margin-bottom:0.75rem">${window.escapeHtml(z.zone)}</div>
                    <div style="display:flex; justify-content:space-between; align-items:flex-end">
                        <div>
                            <div style="font-size:0.85rem; color:var(--text-2); margin-bottom:2px">Risk Score: <span style="font-weight:800; color:var(--text-1)">${z.risk_score}</span></div>
                            <div style="font-size:0.8rem; color:var(--text-3)">Active Reports: <span style="font-weight:600; color:var(--text-2)">${z.active}</span></div>
                        </div>
                        <div style="text-align:right">
                            <div style="font-size:1.5rem; line-height:1; margin-bottom:4px">${trendIcon}</div>
                            <div style="font-size:0.65rem; color:${trendColor}; text-transform:uppercase; font-weight:800; letter-spacing:0.02em">${z.trend}</div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Apply visual circles to map for High/Critical zones
        if (_dashboardMap) {
            data.forEach(z => {
                if (z.risk_score > 40) {
                    // Find a report in this zone to anchor the circle
                    const rep = _reports.find(r => r.zone === z.zone && r.latitude);
                    if (rep) {
                        const col = z.risk_level === 'Critical' ? '#ef4444' : '#f97316';
                        const circle = L.circle([parseFloat(rep.latitude), parseFloat(rep.longitude)], {
                            radius: 800,
                            color: col,
                            fillColor: col,
                            fillOpacity: 0.1,
                            weight: 1,
                            dashArray: '5, 5'
                        }).addTo(_dashboardMap);
                        circle.bindTooltip(`<b>${z.zone}</b>: ${z.risk_level} Risk`, { sticky: true });
                    }
                }
            });
        }
    } catch (e) {
        console.warn('Predictive engine error', e);
        watchlistEl.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:var(--sev-critical);padding:1rem">Risk simulation engine offline</div>';
    }
}

// Expose for inline event handlers
window.updateStatus      = updateStatus;
window.focusMapMarker    = focusMapMarker;
window.downloadCsv       = downloadCsv;
window.saveAdminNotes    = saveAdminNotes;
window.downloadSummaryCsv = downloadSummaryCsv;
