// ============================================================
//  CivicShield AI — Report Submission Page Logic
// ============================================================

document.addEventListener('DOMContentLoaded', async () => {
    // Require auth
    const user = await getSessionUser();
    if (!user) {
        openAuthModal('login');
        // Show login notice in place of the form
        const formEl = document.getElementById('report-form-card');
        if (formEl) {
            formEl.innerHTML = `
              <div class="empty-state">
                <div class="empty-state__icon">🔐</div>
                <h3>Login Required</h3>
                <p class="empty-state__text" style="margin:0.5rem 0 1.25rem">Please sign in to submit a civic report.</p>
                <button class="btn btn-primary" onclick="openAuthModal('login')">Sign In</button>
              </div>`;
        }
        return;
    }

    initUploadZone();
    initGeolocation();
    initReportForm(user);
});

/* ─── File upload zone ───────────────────────────── */
function initUploadZone() {
    const zone     = document.getElementById('upload-zone');
    const input    = document.getElementById('image-input');
    const previewC = document.getElementById('image-preview-container');
    const previewI = document.getElementById('image-preview-img');
    const removeBtn = document.getElementById('image-remove-btn');

    if (!zone) return;

    // Drag & drop
    zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag-over'); });
    zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
    zone.addEventListener('drop', e => {
        e.preventDefault();
        zone.classList.remove('drag-over');
        const file = e.dataTransfer.files[0];
        if (file) handleFileSelected(file);
    });

    input.addEventListener('change', () => {
        if (input.files[0]) handleFileSelected(input.files[0]);
    });

    removeBtn?.addEventListener('click', () => {
        input.value = '';
        previewC.classList.remove('visible');
        previewI.src = '';
    });

    function handleFileSelected(file) {
        if (!file.type.startsWith('image/')) {
            showToast('Please select an image file.', 'error');
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            showToast('Image must be under 5 MB.', 'error');
            return;
        }

        const reader = new FileReader();
        reader.onload = e => {
            previewI.src = e.target.result;
            previewC.classList.add('visible');
        };
        reader.readAsDataURL(file);
    }
}

/* ─── Geolocation ────────────────────────────────── */
function initGeolocation() {
    const btn  = document.getElementById('get-location-btn');
    const latI = document.getElementById('latitude');
    const lngI = document.getElementById('longitude');
    const info = document.getElementById('location-info');

    if (!btn) return;

    btn.addEventListener('click', () => {
        if (!navigator.geolocation) {
            showToast('Geolocation is not supported by your browser.', 'error');
            return;
        }

        btn.innerHTML = '<span class="spinner"></span> Locating…';
        btn.disabled = true;

        navigator.geolocation.getCurrentPosition(
            async pos => {
                const lat = pos.coords.latitude;
                const lng = pos.coords.longitude;
                latI.value = lat.toFixed(7);
                lngI.value = lng.toFixed(7);
                
                btn.innerHTML = '<span class="spinner"></span> Resolving Address…';
                const address = await reverseGeocode(lat, lng);
                const addressInput = document.getElementById('address');
                const addressText  = document.getElementById('address-text');
                const addressWrap  = document.getElementById('address-display');

                if (addressInput) addressInput.value = address;
                if (addressText)  addressText.textContent = address || 'Address not found';
                if (addressWrap)  addressWrap.classList.add('visible');

                btn.innerHTML = '📍 Located!';
                btn.style.color = 'var(--sev-low)';
                btn.style.borderColor = 'var(--sev-low)';
                if (info) info.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
                showToast('Location captured and address resolved.', 'success');
                setTimeout(() => {
                    btn.innerHTML = '📍 Refresh';
                    btn.disabled = false;
                }, 2000);
            },
            err => {
                showToast(`Could not get location: ${err.message}`, 'error');
                btn.innerHTML = '📍 Try Again';
                btn.disabled = false;
            },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    });
}

/**
 * Fetch human-readable address from coordinates using Nominatim (OSM)
 */
async function reverseGeocode(lat, lng) {
    try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`, {
            headers: { 'Accept-Language': 'en' }
        });
        const data = await res.json();
        return data.display_name || '';
    } catch (e) {
        return '';
    }
}

/* ─── Report Form Submission ──────────────────────── */
function initReportForm(user) {
    const form         = document.getElementById('report-form');
    const aiProcessing = document.getElementById('ai-processing-state');
    const aiResult     = document.getElementById('ai-result');
    const submitBtn    = document.getElementById('report-submit-btn');

    if (!form) return;

    form.addEventListener('submit', async e => {
        e.preventDefault();

        const title       = document.getElementById('report-title').value.trim();
        const description = document.getElementById('report-description').value.trim();
        const latitude    = document.getElementById('latitude').value;
        const longitude   = document.getElementById('longitude').value;
        const imageInput  = document.getElementById('image-input');
        const phoneAlt    = document.getElementById('phone_alt')?.value || '';

        // Validation
        if (!title) { showToast('Please enter a title.', 'error'); return; }
        if (description.length < 20) { showToast('Please write a more detailed description (min 20 chars).', 'error'); return; }

        // Build FormData
        const formData = new FormData();
        formData.append('title', title);
        formData.append('description', description);
        if (latitude)  formData.append('latitude',  latitude);
        if (longitude) formData.append('longitude', longitude);
        if (imageInput.files[0]) formData.append('image', imageInput.files[0]);
        const landmark = document.getElementById('landmark-input')?.value?.trim();
        const address  = document.getElementById('address')?.value;
        const zone     = document.getElementById('zone')?.value;
        if (landmark) formData.append('landmark', landmark);
        if (address)  formData.append('address',  address);
        if (zone)     formData.append('zone',      zone);
        if (phoneAlt) formData.append('phone_alt', phoneAlt);

        // Step 1: Submit report
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Submitting…';

        let reportId;
        try {
            const res = await apiFetch('api/report.php', { method: 'POST', body: formData });
            reportId = res.report_id;
        } catch (err) {
            showToast('Failed to submit report: ' + err.message, 'error');
            submitBtn.disabled = false;
            submitBtn.innerHTML = '🚀 Submit Report';
            return;
        }

        // Step 2: Trigger AI processing
        form.style.display = 'none';
        aiProcessing.classList.add('visible');

        try {
            const aiData = await apiFetch('api/ai-process.php', {
                method: 'POST',
                body: JSON.stringify({ report_id: reportId }),
            });

            aiProcessing.classList.remove('visible');
            renderAiResult(aiData);
            aiResult.classList.add('visible');
            aiResult.scrollIntoView({ behavior: 'smooth', block: 'start' });
            showToast('Report submitted successfully! 🎉', 'success');
        } catch (err) {
            aiProcessing.classList.remove('visible');
            // Show form again - AI failed but report was saved
            form.style.display = '';
            submitBtn.disabled = false;
            submitBtn.innerHTML = '🚀 Submit Report';
            showToast('Report saved, but AI analysis failed: ' + err.message + '. Check your Gemini API key.', 'warning');
        }
    });
}

/* ─── Render AI result card ───────────────────────── */
function renderAiResult(data) {
    const scoreEl    = document.getElementById('ai-score');
    const categoryEl = document.getElementById('ai-category-result');
    const severityEl = document.getElementById('ai-severity-label');
    const summaryEl  = document.getElementById('ai-summary-text');
    const recEl      = document.getElementById('ai-recommendation-text');
    const barFill    = document.getElementById('severity-bar-fill');

    if (scoreEl)    scoreEl.textContent    = data.severity_score ?? '—';
    if (scoreEl)    scoreEl.className      = getSeverityClass(data.severity_score) + ' ai-data-item__score';
    if (categoryEl) categoryEl.innerHTML  = categoryBadge(data.category);
    if (severityEl) severityEl.textContent = `${getSeverityLabel(data.severity_score)} Risk`;
    if (severityEl) severityEl.className  = getSeverityClass(data.severity_score) + ' ai-data-item__value';
    if (summaryEl)  summaryEl.textContent  = data.summary || '—';
    if (recEl)      recEl.textContent      = data.recommendation || '—';

    if (barFill) {
        barFill.style.width      = (data.severity_score || 0) + '%';
        barFill.style.background = getSeverityColor(data.severity_score);
    }

    // ── Priority badge
    const priorityColors = { low:'#22c55e', medium:'#eab308', high:'#f97316', critical:'#ef4444' };
    const priorityIcons  = { low:'🟢', medium:'🟡', high:'🟠', critical:'🔴' };
    const pColor = priorityColors[data.priority] || '#6b7280';
    const pIcon  = priorityIcons[data.priority]  || '⚪';
    const priorityBadgeEl = document.getElementById('ai-priority-badge');
    if (priorityBadgeEl) {
        priorityBadgeEl.innerHTML = `<span style="display:inline-flex;align-items:center;gap:.35rem;
            background:${pColor}22;color:${pColor};border:1px solid ${pColor}55;
            padding:.25rem .75rem;border-radius:99px;font-size:.82rem;font-weight:700">
            ${pIcon} ${(data.priority || 'unknown').toUpperCase()} PRIORITY
        </span>`;
    }

    // ── Confidence bar
    const confVal = data.confidence ?? 0;
    const confEl  = document.getElementById('ai-confidence-bar-fill');
    const confTxt = document.getElementById('ai-confidence-text');
    if (confEl)  { confEl.style.width = confVal + '%'; confEl.style.background = confVal >= 70 ? '#22c55e' : confVal >= 40 ? '#eab308' : '#ef4444'; }
    if (confTxt) confTxt.textContent = `${confVal}% confidence`;

    // ── Smart tags
    const tagsEl = document.getElementById('ai-smart-tags');
    if (tagsEl) {
        const tagLabels = {
            traffic_risk:      { label: 'Traffic Risk',       icon: '🚗' },
            near_school:       { label: 'Near School',        icon: '🏫' },
            flood_prone:       { label: 'Flood Prone',        icon: '🌊' },
            electrical_hazard: { label: 'Electrical Hazard',  icon: '⚡' },
            public_safety_risk:{ label: 'Public Safety Risk', icon: '🚨' },
            structural_risk:   { label: 'Structural Risk',    icon: '🏗️' },
            environmental_risk:{ label: 'Environmental Risk', icon: '🌿' },
            recurring_issue:   { label: 'Recurring Issue',    icon: '🔁' },
        };
        const tags = Array.isArray(data.tags) ? data.tags : [];
        if (tags.length) {
            tagsEl.style.display = '';
            tagsEl.innerHTML = tags.map(t => {
                const info = tagLabels[t] || { label: t, icon: '🏷️' };
                return `<span style="display:inline-flex;align-items:center;gap:.3rem;
                    background:rgba(99,102,241,.15);color:var(--primary-light);
                    border:1px solid rgba(99,102,241,.3);padding:.2rem .6rem;
                    border-radius:99px;font-size:.75rem;font-weight:600">
                    ${info.icon} ${info.label}</span>`;
            }).join('');
        } else {
            tagsEl.style.display = 'none';
        }
    }

    // ── Department
    const deptEl = document.getElementById('ai-department-text');
    if (deptEl && data.department) {
        deptEl.closest('.ai-result__section').style.display = '';
        deptEl.textContent = data.department;
    }

    // Update step indicator
    document.querySelectorAll('.form-step').forEach((s, i) => {
        s.classList.toggle('done',   i < 2);
        s.classList.toggle('active', i === 2);
    });
}
