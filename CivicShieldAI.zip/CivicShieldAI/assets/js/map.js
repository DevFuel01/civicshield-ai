// ============================================================
//  CivicShield AI — Leaflet Map Module
//  Features: dark tiles, clustered markers, severity colors,
//             rich popups (image/title/summary/status/badge),
//             severity-weighted heatmap mode toggle
// ============================================================

let _mapInstances  = {};
let _clusterGroups = {};   // per-map MarkerClusterGroup
let _heatLayers    = {};   // per-map heat layer
let _allReports    = {};   // per-map report cache for toggling

// Base URL helper (defined in utils.js)
if (typeof BASE === 'undefined') {
    window.BASE = typeof BASE_URL !== 'undefined' ? BASE_URL : '';
}

/**
 * Initialize a Leaflet map in the given container element ID.
 */
function initMap(containerId, options = {}) {
    if (_mapInstances[containerId]) {
        _mapInstances[containerId].remove();
        delete _mapInstances[containerId];
        delete _clusterGroups[containerId];
        delete _heatLayers[containerId];
    }

    const defaults = {
        center: [6.4541, 3.3947],  // Lagos, Nigeria
        zoom: 13,
        zoomControl: true,
    };

    const map = L.map(containerId, { ...defaults, ...options });

    // Dark CartoDB tiles (OpenStreetMap data)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20,
    }).addTo(map);

    _mapInstances[containerId] = map;
    return map;
}

/**
 * Create a colored SVG drop-pin marker icon based on severity color name.
 */
function createMarkerIcon(color = 'gray', size = 'md') {
    const colorMap = {
        green:  '#22c55e',
        yellow: '#eab308',
        orange: '#f97316',
        red:    '#ef4444',
        gray:   '#6b7280',
    };
    const fill = colorMap[color] || colorMap.gray;
    const w = size === 'sm' ? 22 : 28;
    const h = size === 'sm' ? 28 : 36;

    return L.divIcon({
        html: `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 28 36">
          <path d="M14 0C6.27 0 0 6.27 0 14c0 10.5 14 22 14 22S28 24.5 28 14C28 6.27 21.73 0 14 0z"
                fill="${fill}" opacity="0.95"/>
          <circle cx="14" cy="14" r="7" fill="white" opacity="0.3"/>
          <circle cx="14" cy="14" r="4" fill="white"/>
        </svg>`,
        className: '',
        iconSize:    [w, h],
        iconAnchor:  [w / 2, h],
        popupAnchor: [0, -h],
    });
}

/**
 * Load report markers onto a map with optional clustering.
 * @param {L.Map}  map      - Leaflet map instance
 * @param {Array}  reports  - Report objects from API
 * @param {Object} options  - { fitBounds, maxMarkers, cluster }
 * @returns {number} number of markers placed
 */
function loadMarkers(map, reports, options = {}) {
    const { fitBounds = true, maxMarkers = 400, cluster = true } = options;
    const mapId = _getMapId(map);

    // Remove existing cluster / plain marker layers
    _clearMarkers(map, mapId);

    const validReports = reports.filter(r => r.latitude && r.longitude).slice(0, maxMarkers);
    _allReports[mapId] = validReports;   // cache for heatmap toggle

    const bounds = [];

    // Use MarkerClusterGroup if plugin loaded AND cluster option is true
    const useCluster = cluster && typeof L.markerClusterGroup === 'function';
    const group = useCluster ? L.markerClusterGroup({
        showCoverageOnHover: false,
        maxClusterRadius: 50,
        spiderfyOnMaxZoom: true,
        iconCreateFunction(clust) {
            const count = clust.getChildCount();
            const markers = clust.getAllChildMarkers();
            // Pick worst severity color in cluster
            let worst = 0;
            markers.forEach(m => { if ((m._severityScore || 0) > worst) worst = m._severityScore; });
            const col = worst > 80 ? '#ef4444' : worst > 60 ? '#f97316' : worst > 30 ? '#eab308' : '#22c55e';
            return L.divIcon({
                html: `<div style="background:${col};width:36px;height:36px;border-radius:50%;
                              display:flex;align-items:center;justify-content:center;
                              font-weight:800;font-size:.8rem;color:#fff;
                              border:3px solid rgba(255,255,255,.25);
                              box-shadow:0 2px 8px rgba(0,0,0,.4)">${count}</div>`,
                className: '',
                iconSize: [36, 36],
                iconAnchor: [18, 18],
            });
        },
    }) : L.layerGroup();

    validReports.forEach(report => {
        const lat   = parseFloat(report.latitude);
        const lng   = parseFloat(report.longitude);
        const score = parseInt(report.ai_severity_score, 10) || 0;
        const color = getSeverityMarkerColor(score);
        const icon  = createMarkerIcon(color);

        const marker = L.marker([lat, lng], { icon });
        marker._isReportMarker = true;
        marker._severityScore  = score;
        marker.bindPopup(buildPopupHtml(report), {
            maxWidth: 290,
            className: 'cs-popup',
        });

        group.addLayer(marker);
        bounds.push([lat, lng]);
    });

    group.addTo(map);
    _clusterGroups[mapId] = group;

    if (fitBounds && bounds.length > 0) {
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
    }

    return validReports.length;
}

/**
 * Toggle heatmap mode on/off.
 * Hides/shows cluster markers; adds/removes the Leaflet.heat layer.
 * @param {L.Map} map
 * @param {boolean} enable
 * @returns {boolean} whether heatmap is now active
 */
function toggleHeatmap(map, enable) {
    const mapId = _getMapId(map);
    const group = _clusterGroups[mapId];

    if (enable) {
        // Hide markers
        if (group) map.removeLayer(group);

        // Add heat layer
        const reports = _allReports[mapId] || [];
        const points  = reports.map(r => [
            parseFloat(r.latitude),
            parseFloat(r.longitude),
            Math.max(0.1, (parseInt(r.ai_severity_score, 10) || 50) / 100),
        ]);

        if (typeof L.heatLayer === 'function') {
            const hl = L.heatLayer(points, {
                radius: 30,
                blur: 22,
                maxZoom: 17,
                gradient: { 0.25: '#22c55e', 0.5: '#eab308', 0.75: '#f97316', 1.0: '#ef4444' },
            }).addTo(map);
            _heatLayers[mapId] = hl;
        }
        return true;
    } else {
        // Remove heat layer
        if (_heatLayers[mapId]) { map.removeLayer(_heatLayers[mapId]); delete _heatLayers[mapId]; }
        // Restore markers
        if (group) group.addTo(map);
        return false;
    }
}

/** Build dark-styled popup HTML for a report marker */
function buildPopupHtml(report) {
    const imgHtml = report.image_path
        ? `<img src="${BASE}/${report.image_path}" alt="Report image"
               style="width:100%;height:120px;object-fit:cover;border-radius:8px 8px 0 0;display:block">`
        : '';

    const scoreColor  = getSeverityColor(report.ai_severity_score);
    const score       = report.ai_severity_score ?? '—';
    const priorityMap = { low:'🟢', medium:'🟡', high:'🟠', critical:'🔴' };
    const prioEmoji   = priorityMap[report.ai_priority] || '';

    const statusColors = { pending:'#eab308', 'in-progress':'#6366f1', resolved:'#22c55e' };
    const statusColor  = statusColors[report.status] || '#6b7280';

    const tagsRaw = report.ai_tags;
    let tagsHtml  = '';
    if (tagsRaw) {
        const tags = typeof tagsRaw === 'string' ? JSON.parse(tagsRaw) : tagsRaw;
        if (tags && tags.length) {
            const tagIcons = { traffic_risk:'🚗', near_school:'🏫', flood_prone:'🌊',
                               electrical_hazard:'⚡', public_safety_risk:'🚨',
                               structural_risk:'🏗️', environmental_risk:'🌿', recurring_issue:'🔁' };
            tagsHtml = `<div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:6px">
              ${tags.slice(0, 3).map(t => `<span style="font-size:.65rem;background:#1f2937;color:#9ca3af;
                  padding:1px 5px;border-radius:99px">${tagIcons[t] || '🏷️'} ${t.replace(/_/g,' ')}</span>`).join('')}
            </div>`;
        }
    }

    return `
    <div style="font-family:Inter,sans-serif;min-width:230px;padding:0;overflow:hidden;border-radius:8px">
      ${imgHtml}
      <div style="padding:10px 12px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
          <strong style="font-size:.875rem;color:#f9fafb;flex:1;margin-right:6px">${escapeHtml(report.title)}</strong>
          <span style="font-size:.78rem;font-weight:800;color:${scoreColor};background:${scoreColor}22;
                       padding:2px 8px;border-radius:99px;white-space:nowrap">${prioEmoji} ${score}</span>
        </div>
        <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:6px">
          ${report.ai_category
              ? `<span style="font-size:.7rem;background:#1f2937;color:#9ca3af;padding:2px 6px;border-radius:99px">${report.ai_category}</span>`
              : ''}
          <span style="font-size:.7rem;font-weight:600;color:${statusColor};background:${statusColor}22;padding:2px 6px;border-radius:99px">${report.status}</span>
        </div>
        ${report.ai_summary
            ? `<p style="font-size:.78rem;color:#9ca3af;line-height:1.4;margin:0 0 4px">${escapeHtml(report.ai_summary)}</p>`
            : ''}
        ${tagsHtml}
        <p style="font-size:.68rem;color:#6b7280;margin-top:6px">${formatDate(report.created_at)}</p>
      </div>
    </div>`;
}

/** Clear all marker/cluster layers from map */
function _clearMarkers(map, mapId) {
    if (_clusterGroups[mapId]) { map.removeLayer(_clusterGroups[mapId]); }
    if (_heatLayers[mapId])    { map.removeLayer(_heatLayers[mapId]); }
    map.eachLayer(layer => { if (layer._isReportMarker) map.removeLayer(layer); });
}

/** Get a stable string ID for a map instance */
function _getMapId(map) {
    if (!map._csId) map._csId = '_map_' + Math.random().toString(36).slice(2);
    return map._csId;
}

// ─── Inject popup CSS ─────────────────────────────────────────
const _popupStyle = document.createElement('style');
_popupStyle.textContent = `
  .cs-popup .leaflet-popup-content-wrapper {
    background: #111827;
    color: #f9fafb;
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 8px 32px rgba(0,0,0,.5);
    overflow: hidden;
  }
  .cs-popup .leaflet-popup-content { margin: 0; line-height: 1.4; }
  .cs-popup .leaflet-popup-tip     { background: #111827; }
  .cs-popup .leaflet-popup-close-button { color: #9ca3af; top:4px; right:6px; font-size:18px; }
  .marker-cluster div { border-radius: 50%; }
`;
document.head.appendChild(_popupStyle);
