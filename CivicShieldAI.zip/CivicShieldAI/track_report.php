<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Track Report
//  Citizen Notification & Timeline View
// ─────────────────────────────────────────────
require_once 'config/database.php';

$reportId = isset($_GET['id']) ? (int)$_GET['id'] : null;

if (!$reportId) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Report #<?php echo $reportId; ?> | CivicShield AI</title>

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- Core Styles -->
    <link rel="stylesheet" href="assets/css/main.css">

    <style>
        :root {
            --timeline-width: 2px;
            --timeline-dot-size: 16px;
        }

        body {
            background: var(--bg-dark);
            background-image: var(--bg-gradient);
            min-height: 100vh;
            color: var(--text-main);
        }

        .tracking-container {
            max-width: 900px;
            margin: 4rem auto;
            padding: 0 1.5rem;
            animation: slideUp 0.6s var(--ease-out);
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2.5rem;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-muted);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition-base);
        }

        .btn-back:hover {
            color: var(--primary);
            transform: translateX(-4px);
        }

        /* --- Report Info Card --- */
        .report-hero {
            position: relative;
            background: var(--glass);
            backdrop-filter: var(--blur);
            border: 1px solid var(--glass-border);
            border-radius: 1.5rem;
            padding: 2rem;
            margin-bottom: 3rem;
            overflow: hidden;
            box-shadow: var(--shadow-xl);
        }

        .report-hero::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, var(--primary-glow) 0%, transparent 70%);
            z-index: -1;
            opacity: 0.3;
        }

        .report-badge {
            display: inline-flex;
            padding: 0.4rem 1rem;
            border-radius: 2rem;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 1rem;
        }

        .status-pending {
            background: rgba(245, 158, 11, 0.1);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .status-in-progress {
            background: rgba(59, 130, 246, 0.1);
            color: #60a5fa;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }

        .status-resolved {
            background: rgba(16, 185, 129, 0.1);
            color: #34d399;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .report-title {
            font-family: 'Outfit', sans-serif;
            font-size: 2.25rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #fff 0%, #a1a1aa 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .report-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--glass-border);
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .meta-label {
            color: var(--text-muted);
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .meta-value {
            font-weight: 500;
            color: var(--text-main);
        }

        /* --- Timeline Section --- */
        .timeline-section {
            position: relative;
            padding-left: 3rem;
        }

        .timeline-section::before {
            content: '';
            position: absolute;
            left: 7px;
            top: 0;
            bottom: 0;
            width: var(--timeline-width);
            background: var(--glass-border);
        }

        .timeline-item {
            position: relative;
            margin-bottom: 3rem;
            animation: slideInLeft 0.5s var(--ease-out) both;
        }

        .timeline-item:last-child {
            margin-bottom: 0;
        }

        .timeline-dot {
            position: absolute;
            left: -3rem;
            top: 0.25rem;
            width: var(--timeline-dot-size);
            height: var(--timeline-dot-size);
            background: var(--bg-dark);
            border: 2px solid var(--primary);
            border-radius: 50%;
            z-index: 2;
            box-shadow: 0 0 10px var(--primary-glow);
        }

        .timeline-item.active .timeline-dot {
            background: var(--primary);
            transform: scale(1.2);
        }

        .timeline-content {
            background: var(--glass);
            backdrop-filter: var(--blur);
            border: 1px solid var(--glass-border);
            border-radius: 1rem;
            padding: 1.5rem;
            transition: var(--transition-base);
        }

        .timeline-item:hover .timeline-content {
            border-color: var(--primary);
            transform: translateX(8px);
        }

        .timeline-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.5rem;
        }

        .timeline-status {
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--text-main);
        }

        .timeline-date {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .timeline-message {
            color: var(--text-muted);
            line-height: 1.6;
        }

        /* --- Empty State --- */
        .empty-timeline {
            text-align: center;
            padding: 3rem;
            color: var(--text-muted);
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @media (max-width: 640px) {
            .tracking-container {
                margin: 2rem auto;
            }

            .report-title {
                font-size: 1.75rem;
            }

            .report-meta {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

    <div class="tracking-container">
        <div class="header-section">
            <a href="index.php" class="btn-back">
                <i class="bi bi-arrow-left"></i>
                Back to Home
            </a>
            <div class="report-id-label">REPORT #<?php echo $reportId; ?></div>
        </div>

        <!-- Initial Loader -->
        <div id="loading-view" class="skeleton-view">
            <div class="report-hero skeleton-sweep" style="height: 300px;"></div>
            <div class="timeline-section">
                <div class="timeline-item skeleton-sweep" style="height: 120px; margin-bottom: 2rem;"></div>
                <div class="timeline-item skeleton-sweep" style="height: 120px;"></div>
            </div>
        </div>

        <!-- Content View (Hidden initially) -->
        <div id="content-view" style="display: none;">
            <!-- Report Hero -->
            <div class="report-hero">
                <div id="report-status-badge" class="report-badge">PENDING</div>
                <h1 id="report-title" class="report-title">Loading...</h1>

                <div class="report-meta">
                    <div class="meta-item">
                        <span class="meta-label">Submitted On</span>
                        <span id="meta-date" class="meta-value">---</span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label">Category</span>
                        <span id="meta-category" class="meta-value">---</span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label">Location</span>
                        <span id="meta-location" class="meta-value">---</span>
                    </div>
                </div>
            </div>

            <!-- Timeline -->
            <h3 style="margin-bottom: 2rem; font-family: 'Outfit';">Activity Timeline</h3>
            <div id="timeline-container" class="timeline-section">
                <!-- Timeline items will be injected here -->
            </div>
        </div>
    </div>

    <script src="assets/js/utils.js"></script>
    <script>
        const reportId = <?php echo $reportId; ?>;

        async function initTracking() {
            try {
                const response = await apiFetch(`api/timeline.php?report_id=${reportId}`);
                const data = await response.json();

                if (data.error) {
                    showToast(data.error, 'error');
                    return;
                }

                renderReportInfo(data.report);
                renderTimeline(data.timeline);

                document.getElementById('loading-view').style.display = 'none';
                document.getElementById('content-view').style.display = 'block';

            } catch (err) {
                console.error(err);
                showToast('Failed to load tracking data.', 'error');
            }
        }

        function renderReportInfo(report) {
            document.getElementById('report-title').textContent = report.title;
            document.getElementById('meta-date').textContent = formatDate(report.created_at);
            document.getElementById('meta-category').textContent = report.category || 'Triage Pending';
            document.getElementById('meta-location').textContent = report.address || 'Location data not shared';

            const badge = document.getElementById('report-status-badge');
            badge.textContent = report.current_status.toUpperCase();
            badge.className = `report-badge status-${report.current_status.replace(' ', '-')}`;
        }

        function renderTimeline(timeline) {
            const container = document.getElementById('timeline-container');
            container.innerHTML = '';

            if (timeline.length === 0) {
                container.innerHTML = '<div class="empty-timeline">No activity history found.</div>';
                return;
            }

            timeline.forEach((item, index) => {
                const div = document.createElement('div');
                div.className = `timeline-item ${index === timeline.length - 1 ? 'active' : ''}`;
                div.style.animationDelay = `${index * 0.15}s`;

                div.innerHTML = `
                    <div class="timeline-dot"></div>
                    <div class="timeline-content">
                        <div class="timeline-header">
                            <span class="timeline-status">${item.status}</span>
                            <span class="timeline-date">${formatDate(item.created_at)}</span>
                        </div>
                        ${item.message ? `<div class="timeline-message">${item.message}</div>` : ''}
                    </div>
                `;
                container.appendChild(div);
            });
        }

        document.addEventListener('DOMContentLoaded', initTracking);
    </script>
</body>

</html>