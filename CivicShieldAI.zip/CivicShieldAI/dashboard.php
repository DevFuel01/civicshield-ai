﻿<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Admin / Citizen Dashboard
// ─────────────────────────────────────────────
require_once __DIR__ . '/config/database.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard — CivicShield AI</title>
    <meta name="description" content="Real-time analytics dashboard for civic issue reports. Charts, maps, severity rankings, and status management.">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
</head>

<body>

    <!-- ═══ NAVBAR ════════════════════════════════ -->
    <nav class="navbar">
        <a href="index.php" class="navbar__logo">
            <div class="navbar__logo-icon">🛡️</div>
            CivicShield <span class="text-gradient">AI</span>
        </a>
        <button class="hamburger" id="hamburger" aria-label="Menu"
            onclick="document.getElementById('dashboard-sidebar').classList.toggle('open')">
            <span></span><span></span><span></span>
        </button>
        <ul class="navbar__links" id="navbar-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="report_issue.php">Report Issue</a></li>
            <li><a href="dashboard.php" class="active">Dashboard</a></li>
            <li><a href="profile.php">Profile</a></li>
        </ul>
        <div class="navbar__actions">
            <div id="nav-auth-buttons" style="display:flex;gap:.5rem">
                <button class="btn btn-secondary btn-sm" data-auth-open="login">Sign In</button>
                <button class="btn btn-primary btn-sm" data-auth-open="register">Get Started</button>
            </div>
            <div id="nav-user-info" style="display:none;align-items:center;gap:.75rem">
                <span style="font-size:.875rem;color:var(--text-2)">👤 <strong id="nav-user-name"></strong></span>
                <button class="btn btn-secondary btn-sm" data-logout>Sign Out</button>
            </div>
        </div>
    </nav>

    <!-- ═══ DASHBOARD LAYOUT ══════════════════════ -->
    <div class="dashboard-layout">

        <!-- ─── Sidebar ─────────────────────────── -->
        <aside class="sidebar" id="dashboard-sidebar">

            <div class="sidebar__section-label">Navigation</div>
            <button class="sidebar__nav-item active" data-section="overview">
                <span class="nav-icon">📊</span> Overview
            </button>
            <button class="sidebar__nav-item" data-section="map">
                <span class="nav-icon">🗺️</span> Live Map
            </button>
            <button class="sidebar__nav-item" data-section="analytics">
                <span class="nav-icon">📈</span> Analytics
            </button>
            <button class="sidebar__nav-item" data-section="reports">
                <span class="nav-icon">📋</span> All Reports
            </button>

            <div class="sidebar__section-label admin-only">Admin</div>
            <button class="sidebar__nav-item admin-only" data-section="reports">
                <span class="nav-icon">⚙️</span> Manage Reports
            </button>

            <div class="sidebar__bottom">
                <a href="report_issue.php" class="btn btn-primary btn-block" style="margin-bottom:.5rem">
                    🚨 New Report
                </a>
                <div id="live-time" style="font-size:.72rem;color:var(--text-3);text-align:center;margin-top:.5rem"></div>
            </div>
        </aside>

        <!-- ─── Main Content ─────────────────────── -->
        <main class="dashboard-main">

            <!-- ════ SECTION: OVERVIEW ════════════════ -->
            <div class="dash-section" id="section-overview">

                <div class="dash-header">
                    <div>
                        <h1 class="dash-header__title">Overview <span class="text-gradient">Dashboard</span></h1>
                        <p class="dash-header__subtitle">
                            Welcome back, <strong id="dash-user-name">—</strong>&nbsp;
                            <span class="live-badge"><span class="live-dot"></span>Live</span>
                        </p>
                    </div>
                    <div class="dash-header__actions">
                        <button class="btn btn-secondary btn-sm" id="export-csv-btn">⬇️ Export CSV</button>
                        <a href="report_issue.php" class="btn btn-primary btn-sm">🚨 New Report</a>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-card__icon" style="background:rgba(99,102,241,.15);color:var(--primary-light)">📋</div>
                        <div>
                            <div class="stat-card__value" id="stat-total">—</div>
                            <div class="stat-card__label">Total Reports</div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card__icon" style="background:rgba(234,179,8,.15);color:#eab308">⏳</div>
                        <div>
                            <div class="stat-card__value" id="stat-pending" style="color:#eab308">—</div>
                            <div class="stat-card__label">Pending</div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card__icon" style="background:rgba(99,102,241,.15);color:var(--primary-light)">🔄</div>
                        <div>
                            <div class="stat-card__value" id="stat-progress" style="color:var(--primary-light)">—</div>
                            <div class="stat-card__label">In Progress</div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card__icon" style="background:rgba(34,197,94,.15);color:var(--sev-low)">✅</div>
                        <div>
                            <div class="stat-card__value" id="stat-resolved" style="color:var(--sev-low)">—</div>
                            <div class="stat-card__label">Resolved</div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card__icon" style="background:rgba(239,68,68,.15);color:var(--sev-critical)">⚡</div>
                        <div>
                            <div class="stat-card__value" id="stat-avg-sev" style="color:var(--sev-critical)">—</div>
                            <div class="stat-card__label">Avg Severity</div>
                        </div>
                    </div>
                </div>

                <!-- Charts Row -->
                <div class="charts-grid">
                    <!-- Pie -->
                    <div class="card chart-card">
                        <div class="card__header">
                            <span class="card__title">🟠 Issue Categories</span>
                        </div>
                        <div class="chart-container">
                            <canvas id="pie-chart"></canvas>
                        </div>
                    </div>

                    <!-- Line -->
                    <div class="card chart-card">
                        <div class="card__header">
                            <span class="card__title">📈 Reports Over Time <span style="font-size:.7rem;color:var(--text-3)">(30 days)</span></span>
                        </div>
                        <div class="chart-container chart-container--tall">
                            <canvas id="line-chart"></canvas>
                        </div>
                    </div>

                    <!-- Bar -->
                    <div class="card chart-card">
                        <div class="card__header">
                            <span class="card__title">📊 Severity Distribution</span>
                        </div>
                        <div class="chart-container">
                            <canvas id="bar-chart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- 🔮 Predictive Watchlist -->
                <div class="card table-card" style="margin-bottom: 24px; border-left: 4px solid var(--primary);">
                    <div class="card__header">
                        <span class="card__title">🔮 Predictive <span class="text-gradient">Risk Watchlist</span></span>
                        <span class="live-badge" title="AI analysis of trends and density">AI Simulation Active</span>
                    </div>
                    <div class="watchlist-container" id="predictive-watchlist"
                        style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
                                gap: 1rem; padding: 1.25rem;">
                        <div style="text-align:center; padding: 1rem; color: var(--text-3); grid-column: 1 / -1;">
                            <span class="spinner"></span> Analyzing trends...
                        </div>
                    </div>
                </div>

                <!-- Top 10 High-Risk -->
                <div class="card table-card">
                    <div class="card__header">
                        <span class="card__title">🔴 Top 10 High-Risk Issues</span>
                        <button class="btn btn-secondary btn-sm" onclick="showSection('reports');document.querySelector('[data-section=reports]').click()">View All →</button>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Severity</th>
                                    <th>Urgency</th>
                                    <th>Status</th>
                                    <th>Reporter</th>
                                    <th>Map</th>
                                </tr>
                            </thead>
                            <tbody id="reports-tbody">
                                <tr>
                                    <td colspan="7" style="text-align:center;padding:2rem;color:var(--text-3)">
                                        <span class="spinner spinner-lg"></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- ════ SECTION: MAP ═════════════════════ -->
            <div class="dash-section" id="section-map" style="display:none">
                <div class="dash-header">
                    <div>
                        <h1 class="dash-header__title">Live <span class="text-gradient">Report Map</span></h1>
                        <p class="dash-header__subtitle">All geo-tagged reports plotted by severity</p>
                    </div>
                </div>

                <!-- Legend + Controls -->
                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem;margin-bottom:1rem">
                    <div style="display:flex;gap:1.25rem;font-size:.82rem;flex-wrap:wrap">
                        <span style="color:var(--sev-low)">🟢 Low (0–30)</span>
                        <span style="color:var(--sev-medium)">🟡 Moderate (31–60)</span>
                        <span style="color:var(--sev-high)">🟠 High (61–80)</span>
                        <span style="color:var(--sev-critical)">🔴 Critical (81–100)</span>
                    </div>
                    <div style="display:flex;gap:.5rem">
                        <button id="heatmap-toggle-btn" class="btn btn-secondary btn-sm" title="Toggle severity heatmap overlay">
                            🔥 Heatmap
                        </button>
                    </div>
                </div>

                <div class="map-panel">
                    <div class="map-panel__header">
                        <span style="font-weight:600">🗺️ Interactive Report Map</span>
                        <span class="live-badge"><span class="live-dot"></span>Auto-refreshes every 30s</span>
                    </div>
                    <div id="dashboard-map" style="position: relative;">
                        <!-- Search this Area Button -->
                        <button id="map-search-btn" class="btn btn-primary btn-sm"
                            style="position: absolute; top: 12px; left: 50%; 
                                   transform: translateX(-50%); z-index: 1000; 
                                   display: none; box-shadow: 0 4px 12px rgba(0,0,0,0.3); 
                                   border: 1px solid rgba(255,255,255,0.1);">
                            🔍 Search this area
                        </button>
                    </div>
                </div>
            </div>

            <!-- ════ SECTION: ANALYTICS ══════════════ -->
            <div class="dash-section" id="section-analytics" style="display:none">
                <div class="dash-header">
                    <div>
                        <h1 class="dash-header__title">Analytics <span class="text-gradient">Insights</span></h1>
                        <p class="dash-header__subtitle">Visual breakdown of all civic issues</p>
                    </div>
                    <div class="dash-header__actions">
                        <button class="btn btn-secondary btn-sm" id="export-csv-btn2" onclick="downloadCsv()">⬇️ Export CSV</button>
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
                    <div class="card chart-card">
                        <div class="card__header"><span class="card__title">🟠 Issue Categories</span></div>
                        <div class="chart-container" style="height:300px">
                            <canvas id="pie-chart2"></canvas>
                        </div>
                    </div>
                    <div class="card chart-card">
                        <div class="card__header"><span class="card__title">📊 Severity Distribution</span></div>
                        <div class="chart-container" style="height:300px">
                            <canvas id="bar-chart2"></canvas>
                        </div>
                    </div>
                </div>

                <div class="card chart-card">
                    <div class="card__header"><span class="card__title">📈 Reports Trend (Last 30 Days)</span></div>
                    <div class="chart-container chart-container--tall" style="height:300px">
                        <canvas id="line-chart2"></canvas>
                    </div>
                </div>
            </div>

            <!-- ════ SECTION: ALL REPORTS ════════════ -->
            <div class="dash-section" id="section-reports" style="display:none">
                <div class="dash-header">
                    <div>
                        <h1 class="dash-header__title">All <span class="text-gradient">Reports</span></h1>
                        <p class="dash-header__subtitle">Search, filter, and manage civic issue reports</p>
                    </div>
                    <div class="dash-header__actions">
                        <button class="btn btn-secondary btn-sm" onclick="downloadCsv()">⬇️ Export Reports CSV</button>
                        <button class="btn btn-secondary btn-sm" onclick="downloadSummaryCsv()">📊 Export Summary</button>
                        <a href="report_issue.php" class="btn btn-primary btn-sm">🚨 New Report</a>
                    </div>
                </div>

                <div class="filter-bar" style="flex-wrap:wrap;gap:.5rem">
                    <input class="form-control search-input" id="search-reports"
                        type="text" placeholder="🔍 Search reports…" style="flex:2;min-width:160px">

                    <select class="filter-select" id="filter-status">
                        <option value="">All Statuses</option>
                        <option value="pending">⏳ Pending</option>
                        <option value="in-progress">🔄 In Progress</option>
                        <option value="resolved">✅ Resolved</option>
                    </select>

                    <select class="filter-select" id="filter-category">
                        <option value="">All Categories</option>
                        <option value="pothole">🕳️ Pothole</option>
                        <option value="electrical">⚡ Electrical</option>
                        <option value="flooding">🌊 Flooding</option>
                        <option value="waste">🗑️ Waste</option>
                        <option value="structural damage">🏗️ Structural</option>
                        <option value="other">📌 Other</option>
                    </select>

                    <select class="filter-select" id="filter-severity">
                        <option value="">All Severities</option>
                        <option value="0,30">🟢 Low (0–30)</option>
                        <option value="31,60">🟡 Medium (31–60)</option>
                        <option value="61,80">🟠 High (61–80)</option>
                        <option value="81,100">🔴 Critical (81–100)</option>
                    </select>

                    <input class="filter-select" id="filter-zone" type="text"
                        placeholder="📍 Zone / Area" style="width:130px">

                    <input class="filter-select" id="filter-date-from" type="date"
                        title="From date" style="width:140px">
                    <input class="filter-select" id="filter-date-to" type="date"
                        title="To date" style="width:140px">

                    <select class="filter-select" id="filter-sort" style="width:160px; border-color:var(--primary)">
                        <option value="recent">🕒 Most Recent</option>
                        <option value="risk">🔥 Highest Risk</option>
                        <option value="density">📍 Location Density</option>
                        <option value="intelligent">🧠 Intelligent Rank</option>
                    </select>

                    <button class="btn btn-secondary btn-sm" id="clear-filters-btn">✕ Clear</button>
                </div>

                <div class="card table-card">
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Severity</th>
                                    <th>Urgency</th>
                                    <th>Status</th>
                                    <th>Reporter</th>
                                    <th class="admin-only">Notes</th>
                                    <th>Map</th>
                                </tr>
                            </thead>
                            <tbody id="all-reports-tbody">
                                <tr>
                                    <td colspan="8" style="text-align:center;padding:2rem;color:var(--text-3)">
                                        <span class="spinner spinner-lg"></span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div style="text-align:center; padding: 1rem; border-top: 1px solid var(--border-color)">
                        <button id="load-more-btn" class="btn btn-secondary" style="display:none">
                            🔄 Load More Reports
                        </button>
                    </div>
                </div>
            </div>

        </main>
    </div><!-- /dashboard-layout -->

    <div id="toast-container"></div>

    <!-- External libraries -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
    <script src="https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>

    <!-- App scripts -->
    <script src="assets/js/utils.js"></script>
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/map.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script>
        // Run after dashboard.js has loaded and DOMContentLoaded has fired
        document.addEventListener('DOMContentLoaded', () => {

            // ── Sidebar section switch: analytics duplicate charts ──
            document.querySelectorAll('.sidebar__nav-item[data-section]').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const sec = btn.dataset.section;

                    if (sec === 'analytics') {
                        try {
                            const [cats, tl, sev] = await Promise.all([
                                apiFetch('api/analytics.php?type=categories'),
                                apiFetch('api/analytics.php?type=timeline&days=30'),
                                apiFetch('api/analytics.php?type=severity'),
                            ]);
                            const CHART_COLORS2 = ['#f97316', '#eab308', '#06b6d4', '#22c55e', '#ef4444', '#8b5cf6'];
                            const colorsForSev = {
                                'Low (0-30)': '#22c55e',
                                'Moderate (31-60)': '#eab308',
                                'High (61-80)': '#f97316',
                                'Critical (81-100)': '#ef4444',
                                'Unscored': '#6b7280',
                            };

                            const c2pie = document.getElementById('pie-chart2')?.getContext('2d');
                            if (c2pie) {
                                if (window._pie2) window._pie2.destroy();
                                window._pie2 = new Chart(c2pie, {
                                    type: 'doughnut',
                                    data: {
                                        labels: cats.map(d => d.label),
                                        datasets: [{
                                            data: cats.map(d => d.value),
                                            backgroundColor: CHART_COLORS2,
                                            borderColor: 'transparent',
                                            borderWidth: 2,
                                            hoverOffset: 8
                                        }],
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                position: 'bottom',
                                                labels: {
                                                    padding: 12,
                                                    usePointStyle: true
                                                }
                                            }
                                        },
                                        cutout: '65%'
                                    },
                                });
                            }

                            const c2bar = document.getElementById('bar-chart2')?.getContext('2d');
                            if (c2bar) {
                                if (window._bar2) window._bar2.destroy();
                                window._bar2 = new Chart(c2bar, {
                                    type: 'bar',
                                    data: {
                                        labels: sev.map(d => d.label),
                                        datasets: [{
                                            data: sev.map(d => d.count),
                                            backgroundColor: sev.map(d => colorsForSev[d.label] || '#6b7280'),
                                            borderRadius: 6,
                                            borderSkipped: false
                                        }],
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: false
                                            }
                                        },
                                        scales: {
                                            x: {
                                                grid: {
                                                    color: 'rgba(255,255,255,0.05)'
                                                }
                                            },
                                            y: {
                                                grid: {
                                                    color: 'rgba(255,255,255,0.05)'
                                                },
                                                beginAtZero: true
                                            },
                                        }
                                    },
                                });
                            }

                            const c2line = document.getElementById('line-chart2')?.getContext('2d');
                            if (c2line) {
                                if (window._line2) window._line2.destroy();
                                const grad = c2line.createLinearGradient(0, 0, 0, 300);
                                grad.addColorStop(0, 'rgba(99,102,241,0.4)');
                                grad.addColorStop(1, 'rgba(99,102,241,0)');
                                window._line2 = new Chart(c2line, {
                                    type: 'line',
                                    data: {
                                        labels: tl.map(d => d.date),
                                        datasets: [{
                                            label: 'Reports',
                                            data: tl.map(d => d.count),
                                            borderColor: '#6366f1',
                                            backgroundColor: grad,
                                            borderWidth: 2,
                                            fill: true,
                                            tension: 0.35,
                                            pointRadius: 4
                                        }],
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: false
                                            }
                                        },
                                        scales: {
                                            x: {
                                                grid: {
                                                    color: 'rgba(255,255,255,0.05)'
                                                },
                                                ticks: {
                                                    maxRotation: 45,
                                                    autoSkip: true,
                                                    maxTicksLimit: 8
                                                }
                                            },
                                            y: {
                                                grid: {
                                                    color: 'rgba(255,255,255,0.05)'
                                                },
                                                beginAtZero: true
                                            },
                                        }
                                    },
                                });
                            }
                        } catch (e) {
                            console.warn('Analytics charts error:', e);
                        }
                    }
                });
            });
        });
    </script>


</body>

</html>