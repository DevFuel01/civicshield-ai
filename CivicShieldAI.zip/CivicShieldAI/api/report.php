<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Reports API
//  GET  ?id=X                  -> single report
//  GET  (no id)                -> list reports
//       filters: status, category, severity_min, severity_max, zone, date_from, date_to
//  POST                        -> create report (multipart)
//  PATCH ?id=X                 -> update status + admin_notes (admin only)
// ─────────────────────────────────────────────
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    jsonResponse(['ok' => true]);
}

$method = $_SERVER['REQUEST_METHOD'];
$id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

match (true) {
    $method === 'GET'   && $id !== null => handleGet($id),
    $method === 'GET'                   => handleList(),
    $method === 'POST'                  => handleCreate(),
    $method === 'PATCH' && $id !== null => handleUpdateStatus($id),
    default                             => jsonResponse(['error' => 'Not found.'], 404),
};

// ─── GET single report ───────────────────────
function handleGet(int $id): void
{
    $db   = getDB();
    $stmt = $db->prepare('
        SELECT r.*, u.name AS reporter_name,
               al.ai_summary, al.ai_recommendation,
               al.ai_confidence, al.ai_tags, al.ai_department, al.processed_at
        FROM reports r
        JOIN users u ON r.user_id = u.id
        LEFT JOIN analytics_logs al ON al.report_id = r.id
        WHERE r.id = ?
    ');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        jsonResponse(['error' => 'Report not found.'], 404);
    }
    jsonResponse($row);
}

// ─── GET list reports ────────────────────────
function handleList(): void
{
    $db     = getDB();
    $params = [];
    $where  = [];

    if (!empty($_GET['status'])) {
        $where[]  = 'r.status = ?';
        $params[] = $_GET['status'];
    }
    if (!empty($_GET['category'])) {
        $where[]  = 'r.ai_category = ?';
        $params[] = $_GET['category'];
    }
    // Severity range filter
    if (isset($_GET['severity_min']) && $_GET['severity_min'] !== '') {
        $where[]  = 'r.ai_severity_score >= ?';
        $params[] = (int)$_GET['severity_min'];
    }
    if (isset($_GET['severity_max']) && $_GET['severity_max'] !== '') {
        $where[]  = 'r.ai_severity_score <= ?';
        $params[] = (int)$_GET['severity_max'];
    }
    // Zone / location filter
    if (!empty($_GET['zone'])) {
        $where[]  = 'r.zone LIKE ?';
        $params[] = '%' . $_GET['zone'] . '%';
    }
    // Date range filter
    if (!empty($_GET['date_from'])) {
        $where[]  = 'DATE(r.created_at) >= ?';
        $params[] = $_GET['date_from'];
    }
    if (!empty($_GET['date_to'])) {
        $where[]  = 'DATE(r.created_at) <= ?';
        $params[] = $_GET['date_to'];
    }
    // Map bounds filtering
    if (!empty($_GET['sw_lat']) && !empty($_GET['sw_lng']) && !empty($_GET['ne_lat']) && !empty($_GET['ne_lng'])) {
        $where[]  = 'r.latitude BETWEEN ? AND ?';
        $params[] = (float)$_GET['sw_lat'];
        $params[] = (float)$_GET['ne_lat'];
        $where[]  = 'r.longitude BETWEEN ? AND ?';
        $params[] = (float)$_GET['sw_lng'];
        $params[] = (float)$_GET['ne_lng'];
    }

    // Search filter
    if (!empty($_GET['search'])) {
        $where[]  = '(r.title LIKE ? OR r.description LIKE ?)';
        $params[] = '%' . $_GET['search'] . '%';
        $params[] = '%' . $_GET['search'] . '%';
    }

    $wClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    // Intelligent Prioritization Calculation (SQL-side)
    // 1. Density: Count other unresolved reports in the same zone
    // 2. Time: +2 points for every 24h the report is pending
    // 3. Keywords: +15 points if title/description contains danger/hazard/emergency strings
    $scoreExpr = "
        r.ai_severity_score +
        (SELECT COUNT(*) FROM reports r2 WHERE r2.zone = r.zone AND r2.status != 'resolved' AND r2.id != r.id) * 5 +
        CASE WHEN r.status = 'pending' THEN DATEDIFF(NOW(), r.created_at) * 2 ELSE 0 END +
        CASE WHEN r.title LIKE '%danger%' OR r.title LIKE '%hazard%' OR r.title LIKE '%emergency%' OR r.title LIKE '%fatal%' OR r.title LIKE '%collapse%'
             OR r.description LIKE '%danger%' OR r.description LIKE '%hazard%' OR r.description LIKE '%emergency%' OR r.description LIKE '%fatal%' OR r.description LIKE '%collapse%'
        THEN 15 ELSE 0 END
    ";

    $sort = $_GET['sort'] ?? 'recent';
    $order = 'r.created_at DESC';
    if ($sort === 'risk')    $order = 'r.ai_severity_score DESC';
    if ($sort === 'density') $order = 'density DESC';
    if ($sort === 'intelligent') $order = 'intelligent_score DESC';

    // Pagination
    $page  = max(1, (int)($_GET['page'] ?? 1));
    $limit = max(1, min(100, (int)($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;

    $sql = "
        SELECT r.id, r.title, r.description, r.image_path,
               r.latitude, r.longitude, r.landmark, r.zone, r.address,
               r.ai_category, r.ai_severity_score, r.ai_priority,
               r.status, r.admin_notes, r.created_at,
               u.name AS reporter_name,
               al.ai_summary, al.ai_recommendation, al.ai_tags,
               (SELECT COUNT(*) FROM reports r2 WHERE r2.zone = r.zone AND r2.status != 'resolved' AND r2.id != r.id) AS density,
               ($scoreExpr) AS intelligent_score
        FROM reports r
        JOIN users u ON r.user_id = u.id
        LEFT JOIN analytics_logs al ON al.report_id = r.id
        $wClause
        ORDER BY $order
        LIMIT $limit OFFSET $offset
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    jsonResponse($stmt->fetchAll());
}

// ─── POST create report ──────────────────────
function handleCreate(): void
{
    $user = requireAuth();
    validateCsrf();
    rateLimit('report_create', 10, 3600);

    // Anti-spam Honeypot Check
    if (!empty($_POST['phone_alt'])) {
        logError("Honeypot triggered by IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
        jsonResponse(['error' => 'Spam detected.'], 403);
    }

    $title       = trim(htmlspecialchars($_POST['title']       ?? '', ENT_QUOTES));
    $description = trim(htmlspecialchars($_POST['description'] ?? '', ENT_QUOTES));
    $latitude    = filter_var($_POST['latitude']  ?? null, FILTER_VALIDATE_FLOAT);
    $longitude   = filter_var($_POST['longitude'] ?? null, FILTER_VALIDATE_FLOAT);
    $landmark    = trim(htmlspecialchars($_POST['landmark'] ?? '', ENT_QUOTES)) ?: null;
    $zone        = trim(htmlspecialchars($_POST['zone']     ?? '', ENT_QUOTES)) ?: null;
    $address     = trim(htmlspecialchars($_POST['address']  ?? '', ENT_QUOTES)) ?: null;

    if (!$title || !$description) {
        jsonResponse(['error' => 'Title and description are required.'], 422);
    }

    // Handle file upload
    $imagePath = null;
    if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file    = $_FILES['image'];
        $mime    = mime_content_type($file['tmp_name']);
        $size    = $file['size'];

        if (!in_array($mime, ALLOWED_MIME_TYPES, true)) {
            jsonResponse(['error' => 'Only JPEG, PNG, GIF, and WebP images are allowed.'], 422);
        }
        if ($size > MAX_FILE_SIZE) {
            jsonResponse(['error' => 'Image must be under 5 MB.'], 422);
        }

        $ext       = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename  = bin2hex(random_bytes(16)) . '.jpg'; // Always save as jpg for compression
        $destPath  = UPLOAD_DIR . $filename;

        if (!compressImage($file['tmp_name'], $destPath)) {
            if (!move_uploaded_file($file['tmp_name'], $destPath)) {
                jsonResponse(['error' => 'Failed to save uploaded file.'], 500);
            }
        }
        $imagePath = 'uploads/' . $filename;
    }

    $db   = getDB();
    $stmt = $db->prepare('
        INSERT INTO reports (user_id, title, description, image_path, latitude, longitude, landmark, zone, address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->execute([
        $user['id'],
        $title,
        $description,
        $imagePath,
        $latitude ?: null,
        $longitude ?: null,
        $landmark,
        $zone,
        $address,
    ]);
    $reportId = (int) $db->lastInsertId();

    // Log initial event
    logTimeline($reportId, 'Report Submitted', 'Your issue has been successfully received by the CivicShield system.');

    jsonResponse(['success' => true, 'report_id' => $reportId], 201);
}

// ─── PATCH update status + admin notes (admin) ────
function handleUpdateStatus(int $id): void
{
    $user = requireAuth();
    validateCsrf();
    if ($user['role'] !== 'admin') {
        jsonResponse(['error' => 'Admin access required.'], 403);
    }

    $body       = json_decode(file_get_contents('php://input'), true) ?? [];
    $allowed    = ['pending', 'in-progress', 'resolved'];
    $sets       = [];
    $params     = [];

    if (isset($body['status'])) {
        if (!in_array($body['status'], $allowed, true)) {
            jsonResponse(['error' => 'Invalid status value.'], 422);
        }
        $sets[]   = 'status = ?';
        $params[] = $body['status'];
    }

    if (array_key_exists('admin_notes', $body)) {
        $sets[]   = 'admin_notes = ?';
        $params[] = htmlspecialchars(substr($body['admin_notes'] ?? '', 0, 2000), ENT_QUOTES) ?: null;
    }

    if (empty($sets)) {
        jsonResponse(['error' => 'Nothing to update.'], 422);
    }

    $params[] = $id;
    $db       = getDB();
    $stmt     = $db->prepare('UPDATE reports SET ' . implode(', ', $sets) . ' WHERE id = ?');
    $stmt->execute($params);

    if ($stmt->rowCount() === 0) {
        // If rowCount is 0, it means either report not found OR values didn't change.
        // Let's verify if report exists.
        $check = $db->prepare('SELECT id FROM reports WHERE id = ?');
        $check->execute([$id]);
        if (!$check->fetch()) {
            jsonResponse(['error' => 'Report not found.'], 404);
        }
    }

    // Log to timeline if status changed or message provided
    if (isset($body['status']) || !empty($body['timeline_message'])) {
        $statusLabel = isset($body['status']) ? "Status changed to: " . ucfirst($body['status']) : "Update";
        logTimeline($id, $statusLabel, $body['timeline_message'] ?? null);
    }

    $updated = array_keys(array_filter([
        'status' => isset($body['status']),
        'admin_notes' => isset($body['admin_notes'])
    ]));
    jsonResponse(['success' => true, 'updated' => $updated]);
}

/**
 * Efficiently compress and resize uploaded images using GD
 */
function compressImage(string $source, string $destination, int $quality = 75): bool
{
    if (!function_exists('imagecreatefromjpeg')) return false;

    $info = getimagesize($source);
    if (!$info) return false;

    $image = null;
    switch ($info['mime']) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/webp':
            $image = imagecreatefromwebp($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
    }
    if (!$image) return false;

    // Resize if width > 1200px
    $width = imagesx($image);
    if ($width > 1200) {
        $height    = imagesy($image);
        $newWidth  = 1200;
        $newHeight = (int)($height * ($newWidth / $width));
        $resized   = imagecreatetruecolor($newWidth, $newHeight);
        imagealphablending($resized, false);
        imagesavealpha($resized, true);
        imagecopyresampled($resized, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        imagedestroy($image);
        $image = $resized;
    }

    $res = imagejpeg($image, $destination, $quality);
    imagedestroy($image);
    return $res;
}
