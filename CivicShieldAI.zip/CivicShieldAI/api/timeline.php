<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Timeline API
// ─────────────────────────────────────────────
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

try {
    $db = getDB();
    $reportId = $_GET['report_id'] ?? null;

    if (!$reportId) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing report_id']);
        exit;
    }

    // Fetch timeline entries
    $stmt = $db->prepare('SELECT id, status, message, created_at 
                          FROM report_timeline 
                          WHERE report_id = ? 
                          ORDER BY created_at ASC');
    $stmt->execute([$reportId]);
    $timeline = $stmt->fetchAll();

    // Fetch basic report info for context (optional but helpful)
    $reportStmt = $db->prepare('SELECT title, status as current_status, created_at FROM reports WHERE id = ?');
    $reportStmt->execute([$reportId]);
    $report = $reportStmt->fetch();

    if (!$report) {
        http_response_code(404);
        echo json_encode(['error' => 'Report not found']);
        exit;
    }

    echo json_encode([
        'report'   => $report,
        'timeline' => $timeline
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
