<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Profile API
//  GET  -> get current user profile + their reports
//  PATCH action=update  -> update name / email
//  PATCH action=password -> change password
// ─────────────────────────────────────────────
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    jsonResponse(['ok' => true]);
}

$user   = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'get';

match (true) {
    $method === 'GET'                           => handleGetProfile($user),
    $method === 'PATCH' && $action === 'update'   => handleUpdateProfile($user),
    $method === 'PATCH' && $action === 'password' => handleChangePassword($user),
    default => jsonResponse(['error' => 'Not found.'], 404),
};

// ─── GET profile + own reports ────────────────
function handleGetProfile(array $user): void
{
    $db = getDB();

    // Fetch user row
    $stmt = $db->prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    $profile = $stmt->fetch();

    if (!$profile) {
        jsonResponse(['error' => 'User not found.'], 404);
    }

    // Fetch user's own reports with AI results
    $rStmt = $db->prepare('
        SELECT r.id, r.title, r.description, r.image_path,
               r.latitude, r.longitude,
               r.ai_category, r.ai_severity_score, r.status, r.created_at,
               al.ai_summary, al.ai_recommendation, al.processed_at
        FROM reports r
        LEFT JOIN analytics_logs al ON al.report_id = r.id
        WHERE r.user_id = ?
        ORDER BY r.created_at DESC
    ');
    $rStmt->execute([$user['id']]);
    $reports = $rStmt->fetchAll();

    // Stats
    $total    = count($reports);
    $resolved = count(array_filter($reports, fn($r) => $r['status'] === 'resolved'));
    $pending  = count(array_filter($reports, fn($r) => $r['status'] === 'pending'));

    jsonResponse([
        'profile' => $profile,
        'reports' => $reports,
        'stats'   => [
            'total'    => $total,
            'resolved' => $resolved,
            'pending'  => $pending,
        ],
    ]);
}

// ─── PATCH update name/email ──────────────────
function handleUpdateProfile(array $user): void
{
    $body  = json_decode(file_get_contents('php://input'), true) ?? [];
    $name  = trim(htmlspecialchars($body['name']  ?? '', ENT_QUOTES));
    $email = trim(filter_var($body['email'] ?? '', FILTER_VALIDATE_EMAIL));

    if (!$name || !$email) {
        jsonResponse(['error' => 'Valid name and email are required.'], 422);
    }

    $db = getDB();

    // Check email not taken by another user
    $check = $db->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
    $check->execute([$email, $user['id']]);
    if ($check->fetch()) {
        jsonResponse(['error' => 'That email is already in use by another account.'], 409);
    }

    $stmt = $db->prepare('UPDATE users SET name = ?, email = ? WHERE id = ?');
    $stmt->execute([$name, $email, $user['id']]);

    // Update session
    $_SESSION['user_name'] = $name;

    jsonResponse(['success' => true, 'name' => $name, 'email' => $email]);
}

// ─── PATCH change password ────────────────────
function handleChangePassword(array $user): void
{
    $body        = json_decode(file_get_contents('php://input'), true) ?? [];
    $currentPass = $body['current_password'] ?? '';
    $newPass     = $body['new_password']     ?? '';

    if (!$currentPass || strlen($newPass) < 6) {
        jsonResponse(['error' => 'Current password and new password (min 6 chars) are required.'], 422);
    }

    $db   = getDB();
    $stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    $row  = $stmt->fetch();

    if (!$row || !password_verify($currentPass, $row['password'])) {
        jsonResponse(['error' => 'Current password is incorrect.'], 401);
    }

    $hashed = password_hash($newPass, PASSWORD_BCRYPT, ['cost' => 12]);
    $upd    = $db->prepare('UPDATE users SET password = ? WHERE id = ?');
    $upd->execute([$hashed, $user['id']]);

    jsonResponse(['success' => true, 'message' => 'Password updated successfully.']);
}
