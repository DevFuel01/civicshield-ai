<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Auth API
//  Endpoints: ?action=register|login|logout|me
// ─────────────────────────────────────────────
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    jsonResponse(['ok' => true]);
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'register':
        handleRegister();
        break;
    case 'login':
        handleLogin();
        break;
    case 'logout':
        handleLogout();
        break;
    case 'me':
        handleMe();
        break;
    default:
        jsonResponse(['error' => 'Unknown action.'], 400);
}

// ─── Register ────────────────────────────────
function handleRegister(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Method not allowed.'], 405);
    }
    validateCsrf();

    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    $name  = trim(filter_var($body['name']  ?? '', FILTER_SANITIZE_STRING));
    $email = trim(filter_var($body['email'] ?? '', FILTER_VALIDATE_EMAIL));
    $pass  = $body['password'] ?? '';

    if (!$name || !$email || strlen($pass) < 6) {
        jsonResponse(['error' => 'Name, valid email, and password (min 6 chars) are required.'], 422);
    }

    $db = getDB();

    // Check duplicate
    $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(['error' => 'Email already registered.'], 409);
    }

    $hashed = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 12]);
    $stmt = $db->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
    $stmt->execute([$name, $email, $hashed]);
    $userId = (int) $db->lastInsertId();

    // Auto-login after register
    session_regenerate_id(true);
    $_SESSION['user_id']   = $userId;
    $_SESSION['user_name'] = $name;
    $_SESSION['user_role'] = 'citizen';
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    jsonResponse([
        'success'    => true,
        'user'       => ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => 'citizen'],
        'csrf_token' => $_SESSION['csrf_token'],
    ], 201);
}

// ─── Login ───────────────────────────────────
function handleLogin(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Method not allowed.'], 405);
    }
    validateCsrf();

    $body  = json_decode(file_get_contents('php://input'), true) ?? [];
    $email = trim(filter_var($body['email'] ?? '', FILTER_VALIDATE_EMAIL));
    $pass  = $body['password'] ?? '';

    if (!$email || !$pass) {
        jsonResponse(['error' => 'Email and password are required.'], 422);
    }

    $db   = getDB();
    $stmt = $db->prepare('SELECT id, name, email, password, role FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($pass, $user['password'])) {
        jsonResponse(['error' => 'Invalid email or password.'], 401);
    }

    session_regenerate_id(true);
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_role']  = $user['role'];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    jsonResponse([
        'success'    => true,
        'user'       => ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']],
        'csrf_token' => $_SESSION['csrf_token'],
    ]);
}

// ─── Logout ──────────────────────────────────
function handleLogout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    jsonResponse(['success' => true]);
}

// ─── Me (current user) ───────────────────────
function handleMe(): void
{
    if (empty($_SESSION['user_id'])) {
        jsonResponse([
            'authenticated' => false,
            'csrf_token'    => getCsrfToken()
        ]);
    }
    jsonResponse([
        'authenticated' => true,
        'user' => [
            'id'   => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'],
            'role' => $_SESSION['user_role'],
        ],
        'csrf_token' => getCsrfToken(),
    ]);
}
