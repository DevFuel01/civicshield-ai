<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Analytics API
//  GET ?type=categories|timeline|severity|top_risks|stats|predictive|export
// ─────────────────────────────────────────────
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    jsonResponse(['ok' => true]);
}

$type = $_GET['type'] ?? 'stats';

match ($type) {
    'categories'     => getCategories(),
    'timeline'       => getTimeline(),
    'severity'       => getSeverity(),
    'top_risks'      => getTopRisks(),
    'stats'          => getStats(),
    'predictive'     => getPredictive(),
    'export'         => exportCsv(),
    'summary_export' => exportSummary(),
    default          => jsonResponse(['error' => 'Unknown type.'], 400),
};

// ─── Stats summary cards ──────────────────────
function getStats(): void
{
    $db   = getDB();
    $stmt = $db->query('
        SELECT
            COUNT(*) AS total,
            SUM(status = "pending") AS pending,
            SUM(status = "in-progress") AS in_progress,
            SUM(status = "resolved") AS resolved,
            ROUND(AVG(ai_severity_score), 1) AS avg_severity
        FROM reports
    ');
    jsonResponse($stmt->fetch());
}

// ─── Category distribution (pie chart) ───────
function getCategories(): void
{
    $cache = getCache('categories');
    if ($cache) {
        jsonResponse($cache);
        return;
    }

    $db   = getDB();
    $stmt = $db->query('
        SELECT
            COALESCE(ai_category, "unclassified") AS label,
            COUNT(*) AS value
        FROM reports
        GROUP BY ai_category
        ORDER BY value DESC
    ');
    jsonResponse($stmt->fetchAll());
}

// ─── Reports by day (line chart) ─────────────
function getTimeline(): void
{
    $db   = getDB();
    $days = max(1, min(90, (int)($_GET['days'] ?? 30)));
    $stmt = $db->prepare('
        SELECT
            DATE(created_at) AS date,
            COUNT(*)         AS count
        FROM reports
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ');
    $stmt->execute([$days]);
    jsonResponse($stmt->fetchAll());
}

// ─── Severity distribution (bar chart) ───────
function getSeverity(): void
{
    $db   = getDB();
    $stmt = $db->query('
        SELECT
            CASE
                WHEN ai_severity_score BETWEEN 0  AND 30  THEN "Low (0-30)"
                WHEN ai_severity_score BETWEEN 31 AND 60  THEN "Moderate (31-60)"
                WHEN ai_severity_score BETWEEN 61 AND 80  THEN "High (61-80)"
                WHEN ai_severity_score BETWEEN 81 AND 100 THEN "Critical (81-100)"
                ELSE "Unscored"
            END AS label,
            COUNT(*) AS count
        FROM reports
        GROUP BY label
        ORDER BY MIN(ai_severity_score) ASC
    ');
    jsonResponse($stmt->fetchAll());
}

// ─── Top 10 high-risk reports ─────────────────
function getTopRisks(): void
{
    $db   = getDB();
    $stmt = $db->query('
        SELECT
            r.id, r.title, r.ai_category, r.ai_severity_score,
            r.status, r.created_at,
            u.name AS reporter_name,
            al.ai_summary, al.ai_recommendation
        FROM reports r
        JOIN users u ON r.user_id = u.id
        LEFT JOIN analytics_logs al ON al.report_id = r.id
        ORDER BY r.ai_severity_score DESC
        LIMIT 10
    ');
    jsonResponse($stmt->fetchAll());
}

// ─── CSV export (raw rows) ─────────────────
function exportCsv(): void
{
    $db   = getDB();
    $stmt = $db->query('
        SELECT r.id, r.title, r.description,
               r.ai_category, r.ai_severity_score, r.ai_priority,
               r.status, r.admin_notes,
               r.landmark, r.zone, r.address,
               r.latitude, r.longitude, r.created_at,
               u.name AS reporter,
               al.ai_summary, al.ai_recommendation, al.ai_department, al.ai_confidence
        FROM reports r
        JOIN users u ON r.user_id = u.id
        LEFT JOIN analytics_logs al ON al.report_id = r.id
        ORDER BY r.created_at DESC
    ');
    $rows = $stmt->fetchAll();

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="civicshield_reports_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store');

    $out = fopen('php://output', 'w');
    if (!empty($rows)) {
        fputcsv($out, array_keys($rows[0]));
        foreach ($rows as $row) {
            fputcsv($out, $row);
        }
    }
    fclose($out);
    exit;
}

// ─── Analytics Summary CSV export ────────────
function exportSummary(): void
{
    $db = getDB();

    // Overall stats
    $stats = $db->query('
        SELECT COUNT(*) AS total_reports,
               SUM(status = "pending")     AS pending,
               SUM(status = "in-progress") AS in_progress,
               SUM(status = "resolved")    AS resolved,
               ROUND(AVG(ai_severity_score), 1) AS avg_severity,
               SUM(ai_priority = "critical") AS critical_count,
               SUM(ai_priority = "high")     AS high_count
        FROM reports
    ')->fetch();

    // Category breakdown
    $cats = $db->query('
        SELECT COALESCE(ai_category, "unclassified") AS category, COUNT(*) AS count
        FROM reports GROUP BY ai_category ORDER BY count DESC
    ')->fetchAll();

    // Priority breakdown
    $priorities = $db->query('
        SELECT COALESCE(ai_priority, "unscored") AS priority, COUNT(*) AS count
        FROM reports GROUP BY ai_priority ORDER BY count DESC
    ')->fetchAll();

    // Top 5 critical
    $top5 = $db->query('
        SELECT r.id, r.title, r.ai_category, r.ai_severity_score, r.status, r.created_at,
               u.name AS reporter, al.ai_summary
        FROM reports r
        JOIN users u ON r.user_id = u.id
        LEFT JOIN analytics_logs al ON al.report_id = r.id
        ORDER BY r.ai_severity_score DESC LIMIT 5
    ')->fetchAll();

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="civicshield_summary_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store');

    $out = fopen('php://output', 'w');

    fputcsv($out, ['CIVICSHIELD AI — ANALYTICS SUMMARY', 'Generated: ' . date('Y-m-d H:i:s')]);
    fputcsv($out, []);

    fputcsv($out, ['OVERALL STATISTICS']);
    foreach ($stats as $k => $v) fputcsv($out, [ucwords(str_replace('_', ' ', $k)), $v]);
    fputcsv($out, []);

    fputcsv($out, ['CATEGORY BREAKDOWN']);
    fputcsv($out, ['Category', 'Count']);
    foreach ($cats as $r) fputcsv($out, [$r['category'], $r['count']]);
    fputcsv($out, []);

    fputcsv($out, ['PRIORITY BREAKDOWN']);
    fputcsv($out, ['Priority', 'Count']);
    foreach ($priorities as $r) fputcsv($out, [$r['priority'], $r['count']]);
    fputcsv($out, []);

    fputcsv($out, ['TOP 5 CRITICAL REPORTS']);
    fputcsv($out, ['ID', 'Title', 'Category', 'Severity', 'Status', 'Reporter', 'AI Summary']);
    foreach ($top5 as $r) {
        fputcsv($out, [
            $r['id'],
            $r['title'],
            $r['ai_category'],
            $r['ai_severity_score'],
            $r['status'],
            $r['reporter'],
            $r['ai_summary']
        ]);
    }

    fclose($out);
    exit;
}

// ─── Predictive Risk Engine ──────────────────
// Risk Score = (TotalActive * 10) + (AvgSeverity * 1.5) + (RecentGrowth * 20)
function getPredictive(): void
{
    $cache = getCache('predictive');
    if ($cache) {
        jsonResponse($cache);
        return;
    }

    $db = getDB();

    // Risk Score = (TotalActive * 10) + (AvgSeverity * 1.5) + (RecentGrowth * 20)
    // Growth = CountLast7Days - CountPrevious7Days
    $stmt = $db->query("
        SELECT
            zone,
            COUNT(*) AS total_reports,
            SUM(CASE WHEN status != 'resolved' THEN 1 ELSE 0 END) AS active_reports,
            ROUND(AVG(ai_severity_score), 1) AS avg_severity,
            SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) 
                     AND created_at < DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS count_old
        FROM reports
        WHERE zone IS NOT NULL AND zone != ''
        GROUP BY zone
        HAVING total_reports > 0
        ORDER BY active_reports DESC
    ");

    $zones = $stmt->fetchAll();
    $watchlist = [];

    foreach ($zones as $z) {
        $growth = (int)$z['count_recent'] - (int)$z['count_old'];
        $avgSev = (float)($z['avg_severity'] ?? 0);
        $score  = ($z['active_reports'] * 10) + ($avgSev * 1.5) + ($growth * 20);
        $score  = max(0, (float)$score);

        $trend = 'stable';
        if ($growth > 0) $trend = 'escalating';
        if ($growth < 0) $trend = 'stabilizing';

        $watchlist[] = [
            'zone'           => $z['zone'],
            'total'          => (int)$z['total_reports'],
            'active'         => (int)$z['active_reports'],
            'avg_severity'   => (float)$z['avg_severity'],
            'recent_growth'  => $growth,
            'risk_score'     => round($score, 1),
            'trend'          => $trend,
            'risk_level'     => $score > 80 ? 'Critical' : ($score > 40 ? 'High' : 'Moderate')
        ];
    }

    // Sort by Risk Score DESC
    usort($watchlist, fn($a, $b) => $b['risk_score'] <=> $a['risk_score']);

    $res = array_slice($watchlist, 0, 5);
    setCache('predictive', $res);
    jsonResponse($res);
}

/**
 * File-based caching helpers
 */
function getCache(string $key, int $ttl = 300): ?array
{
    $cacheDir = __DIR__ . '/../logs/cache/';
    $cacheFile = $cacheDir . md5($key) . '.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile) < $ttl)) {
        return json_decode(file_get_contents($cacheFile), true);
    }
    return null;
}

function setCache(string $key, array $data): void
{
    $cacheDir = __DIR__ . '/../logs/cache/';
    if (!is_dir($cacheDir)) {
        mkdir($cacheDir, 0777, true);
    }
    file_put_contents($cacheDir . md5($key) . '.json', json_encode($data));
}
