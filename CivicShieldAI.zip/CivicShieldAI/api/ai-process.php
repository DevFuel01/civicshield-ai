<?php
// =============================================================================
//  CivicShield AI - Gemini AI Processing Endpoint
//  POST body: { "report_id": int }
//  Returns: category, severity_score, priority, confidence, tags, summary,
//           recommendation, department
// =============================================================================
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed.'], 405);
}

$body     = json_decode(file_get_contents('php://input'), true) ?? [];
$reportId = (int)($body['report_id'] ?? 0);

if (!$reportId) {
    jsonResponse(['error' => 'report_id is required.'], 422);
}

$db   = getDB();
$stmt = $db->prepare(
    'SELECT id, title, description, landmark, zone FROM reports WHERE id = ?'
);
$stmt->execute([$reportId]);
$report = $stmt->fetch();
if (!$report) {
    jsonResponse(['error' => 'Report not found.'], 404);
}

// =============================================================================
//  Build Gemini Prompt — expanded for all triage fields
// =============================================================================
$landmark = $report['landmark'] ? "Nearest Landmark: {$report['landmark']}" : '';
$zone     = $report['zone']     ? "Zone/Area: {$report['zone']}"             : '';

$promptText = <<<PROMPT
You are an expert civic infrastructure triage analyst AI for a smart city platform.
Analyze the following citizen-reported civic issue and produce a comprehensive, structured assessment.

Issue Title: {$report['title']}
Issue Description: {$report['description']}
{$landmark}
{$zone}

Respond ONLY with a valid JSON object in exactly this format (no markdown, no extra text, no code fences):
{
  "category": "<one of: pothole, electrical, flooding, waste, structural damage, other>",
  "severity_score": <integer 0-100>,
  "priority": "<one of: low, medium, high, critical>",
  "confidence": <integer 0-100>,
  "summary": "<concise 1-2 sentence public-friendly summary of the issue>",
  "recommendation": "<specific actionable recommendation for civic authorities. Include immediate safety steps if needed.>",
  "department": "<name of the most appropriate responsible government department or agency>",
  "tags": ["<select all that apply from: traffic_risk, near_school, flood_prone, electrical_hazard, public_safety_risk, structural_risk, environmental_risk, recurring_issue>"]
}

Scoring guides:
SEVERITY (0-100):
  0-30   = Low    — cosmetic or minor inconvenience
  31-60  = Medium — requires attention within weeks
  61-80  = High   — urgent, requires response within days
  81-100 = Critical — immediate emergency response required

PRIORITY must match the severity band:
  0-30   -> "low"
  31-60  -> "medium"
  61-80  -> "high"
  81-100 -> "critical"

CONFIDENCE (0-100): Your confidence level in this assessment based on the available information.

DEPARTMENT examples: "Roads & Infrastructure Department", "Electrical Utility Board",
  "Drainage & Flood Control Authority", "Waste Management Agency",
  "Structural Engineering & Buildings", "Environmental Health Department"

TAGS — include only those that genuinely apply:
  traffic_risk      — issue directly affects vehicular or pedestrian traffic
  near_school       — issue is near or affects access to a school
  flood_prone       — area is prone to flooding or issue worsens floods
  electrical_hazard — exposed wires, downed poles, or electrical danger present
  public_safety_risk — direct risk to public health or safety
  structural_risk   — risk of building or infrastructure collapse
  environmental_risk — pollution, contamination, or ecological risk
  recurring_issue   — common/recurring problem type in urban areas
PROMPT;

// =============================================================================
//  Call Gemini API
// =============================================================================
$payload = [
    'contents' => [
        [
            'parts' => [
                ['text' => $promptText],
            ],
        ],
    ],
    'generationConfig' => [
        'temperature'     => 0.1,
        'topK'            => 1,
        'topP'            => 0.8,
        'maxOutputTokens' => 1024,
    ],
];

$apiUrl = GEMINI_API_ENDPOINT . '?key=' . GEMINI_API_KEY;
$ch     = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$rawResponse = curl_exec($ch);
$curlError   = curl_error($ch);
$httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curlError) {
    jsonResponse(['error' => 'Gemini API connection failed: ' . $curlError], 503);
}
if ($httpCode !== 200) {
    $errBody = json_decode($rawResponse, true);
    $errMsg  = $errBody['error']['message'] ?? 'Gemini API returned HTTP ' . $httpCode;
    jsonResponse(['error' => $errMsg], 503);
}

// =============================================================================
//  Parse Gemini response
// =============================================================================
$geminiData  = json_decode($rawResponse, true);
$textContent = $geminiData['candidates'][0]['content']['parts'][0]['text'] ?? null;

if (!$textContent) {
    jsonResponse(['error' => 'No content returned from Gemini.'], 502);
}

// Strip markdown code fences Gemini sometimes adds
$textContent = preg_replace('/^```json\s*/i', '', trim($textContent));
$textContent = preg_replace('/^```\s*/i',     '', $textContent);
$textContent = preg_replace('/```\s*$/',      '', $textContent);

$aiResult = json_decode(trim($textContent), true);

$required = ['category', 'severity_score', 'priority', 'confidence', 'summary', 'recommendation'];
foreach ($required as $field) {
    if (!isset($aiResult[$field])) {
        jsonResponse(['error' => "AI response missing field: {$field}", 'raw' => $textContent], 502);
    }
}

// =============================================================================
//  Validate & sanitise all fields
// =============================================================================
$allowedCategories = ['pothole', 'electrical', 'flooding', 'waste', 'structural damage', 'other'];
$allowedPriorities = ['low', 'medium', 'high', 'critical'];
$allowedTags       = [
    'traffic_risk',
    'near_school',
    'flood_prone',
    'electrical_hazard',
    'public_safety_risk',
    'structural_risk',
    'environmental_risk',
    'recurring_issue',
];

$category       = in_array($aiResult['category'], $allowedCategories, true)
    ? $aiResult['category'] : 'other';
$severityScore  = max(0, min(100, (int)$aiResult['severity_score']));
$priority       = in_array($aiResult['priority'] ?? '', $allowedPriorities, true)
    ? $aiResult['priority'] : derivePriority($severityScore);
$confidence     = max(0, min(100, (int)($aiResult['confidence'] ?? 75)));
$summary        = htmlspecialchars(substr($aiResult['summary'],        0, 1000), ENT_QUOTES);
$recommendation = htmlspecialchars(substr($aiResult['recommendation'], 0, 1000), ENT_QUOTES);
$department     = htmlspecialchars(substr($aiResult['department'] ?? '', 0, 120), ENT_QUOTES);

// Validate tags — only keep recognised ones
$rawTags     = is_array($aiResult['tags'] ?? null) ? $aiResult['tags'] : [];
$validatedTags = array_values(
    array_filter($rawTags, fn($t) => in_array($t, $allowedTags, true))
);
$tagsJson = json_encode($validatedTags);

// =============================================================================
//  Store results in database
// =============================================================================
try {
    $db->beginTransaction();

    $stmt = $db->prepare('
        UPDATE reports
        SET ai_category = ?, ai_severity_score = ?, ai_priority = ?
        WHERE id = ?
    ');
    $stmt->execute([$category, $severityScore, $priority, $reportId]);

    // Upsert analytics_log
    $del = $db->prepare('DELETE FROM analytics_logs WHERE report_id = ?');
    $del->execute([$reportId]);

    $ins = $db->prepare('
        INSERT INTO analytics_logs
            (report_id, ai_summary, ai_recommendation, ai_confidence, ai_tags, ai_department)
        VALUES (?, ?, ?, ?, ?, ?)
    ');
    $ins->execute([$reportId, $summary, $recommendation, $confidence, $tagsJson, $department]);

    $db->commit();

    // Log to timeline
    logTimeline($reportId, 'AI Triage Complete', 'CivicShield AI has analyzed your report and assigned it to the ' . $department . '. Coverage and severity have been assessed.');
} catch (PDOException $e) {
    $db->rollBack();
    jsonResponse(['error' => 'Database error storing AI results: ' . $e->getMessage()], 500);
}

jsonResponse([
    'success'        => true,
    'report_id'      => $reportId,
    'category'       => $category,
    'severity_score' => $severityScore,
    'priority'       => $priority,
    'confidence'     => $confidence,
    'tags'           => $validatedTags,
    'summary'        => $summary,
    'recommendation' => $recommendation,
    'department'     => $department,
]);

// =============================================================================
//  Helpers
// =============================================================================
function derivePriority(int $score): string
{
    if ($score <= 30) return 'low';
    if ($score <= 60) return 'medium';
    if ($score <= 80) return 'high';
    return 'critical';
}
