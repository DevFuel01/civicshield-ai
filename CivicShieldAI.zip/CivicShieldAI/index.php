<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Homepage
// ─────────────────────────────────────────────
require_once __DIR__ . '/config/database.php';

// Fetch quick stats for hero section
$db = getDB();
$stats = $db->query('SELECT COUNT(*) AS total, SUM(status="resolved") AS resolved, SUM(status="pending") AS pending FROM reports')->fetch();
$latestReports = $db->query('SELECT id,title,latitude,longitude,ai_category,ai_severity_score,status,created_at FROM reports WHERE latitude IS NOT NULL ORDER BY created_at DESC LIMIT 40')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CivicShield AI — Smart Civic Issue Reporting</title>
    <meta name="description" content="AI-powered civic issue reporting platform. Report potholes, flooding, electrical faults, and more. Get instant AI analysis and track resolution.">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        /* ── Hero ─────────────────────────────── */
        .hero {
            padding: 160px 0 100px;
            position: relative;
            overflow: hidden;
            text-align: center;
            background: radial-gradient(circle at 50% -20%, rgba(99, 102, 241, 0.15), transparent 60%);
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%236366f1' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            pointer-events: none;
        }

        .hero__eyebrow {
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            background: rgba(99, 102, 241, .08);
            border: 1px solid var(--border-bright);
            backdrop-filter: var(--blur);
            -webkit-backdrop-filter: var(--blur);
            color: var(--primary-light);
            padding: .4rem 1.25rem;
            border-radius: 99px;
            font-size: .75rem;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
            margin-bottom: 2rem;
            box-shadow: var(--glow);
            animation: slideUp .6s var(--ease-out);
        }

        .hero__title {
            margin-bottom: 1.5rem;
            font-weight: 900;
            letter-spacing: -0.02em;
            animation: slideUp .6s var(--ease-out) .1s both;
        }

        .hero__desc {
            color: var(--text-2);
            font-size: 1.2rem;
            max-width: 640px;
            margin: 0 auto 3rem;
            line-height: 1.6;
            animation: slideUp .6s var(--ease-out) .2s both;
        }

        .hero__cta {
            display: flex;
            gap: 1.25rem;
            justify-content: center;
            flex-wrap: wrap;
            animation: slideUp .6s var(--ease-out) .3s both;
        }

        /* Hero stats strip */
        .hero-stats {
            display: flex;
            justify-content: center;
            gap: 4rem;
            margin-top: 6rem;
            animation: slideUp .6s var(--ease-out) .4s both;
        }

        .hero-stat {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
        }

        .hero-stat__value {
            font-size: 2.5rem;
            font-weight: 900;
            background: linear-gradient(135deg, var(--text) 0%, var(--text-2) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-stat__label {
            color: var(--text-3);
            font-size: .8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }

        /* ── Mini Map ─────────────────────────── */
        .mini-map-wrap {
            border-radius: var(--radius-lg);
            overflow: hidden;
            border: 1px solid var(--border);
            box-shadow: var(--shadow-lg);
            max-width: 900px;
            margin: 0 auto 2rem;
            animation: slideUp .6s ease .5s both;
        }

        #hero-map {
            height: 380px;
        }

        /* ── Features ─────────────────────────── */
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
        }

        @media(max-width:768px) {
            .feature-grid {
                grid-template-columns: 1fr;
            }
        }

        .feature-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 2rem;
            text-align: center;
            transition: all var(--transition);
        }

        .feature-card:hover {
            border-color: rgba(99, 102, 241, .4);
            box-shadow: var(--glow);
            transform: translateY(-4px);
        }

        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            display: block;
        }

        .feature-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: .5rem;
        }

        .feature-desc {
            color: var(--text-2);
            font-size: .9rem;
        }

        /* ── How It Works ─────────────────────── */
        .steps-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.5rem;
        }

        @media(max-width:900px) {
            .steps-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media(max-width:500px) {
            .steps-grid {
                grid-template-columns: 1fr;
            }
        }

        .step-card {
            text-align: center;
            padding: 1.5rem;
        }

        .step-num {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            border-radius: 50%;
            display: grid;
            place-items: center;
            font-size: 1.1rem;
            font-weight: 800;
            margin: 0 auto 1rem;
            box-shadow: 0 4px 16px rgba(99, 102, 241, .35);
        }

        /* ── CTA Banner ───────────────────────── */
        .cta-banner {
            background: linear-gradient(135deg, rgba(99, 102, 241, .2), rgba(6, 182, 212, .15));
            border: 1px solid rgba(99, 102, 241, .25);
            border-radius: var(--radius-lg);
            padding: 4rem 2rem;
            text-align: center;
        }

        /* ── Recent Reports Preview ───────────── */
        .reports-preview {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1rem;
        }

        .report-preview-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.25rem;
            transition: all var(--transition);
        }

        .report-preview-card:hover {
            border-color: rgba(99, 102, 241, .3);
            transform: translateY(-2px);
        }
    </style>
</head>

<body>

    <!-- ═══ NAVBAR ════════════════════════════════ -->
    <nav class="navbar">
        <a href="index.php" class="navbar__logo">
            <div class="navbar__logo-icon">🛡️</div>
            CivicShield <span class="text-gradient">AI</span>
        </a>

        <button class="hamburger" id="hamburger" aria-label="Menu">
            <span></span><span></span><span></span>
        </button>

        <ul class="navbar__links" id="navbar-links">
            <li><a href="index.php" class="active">Home</a></li>
            <li><a href="report_issue.php">Report Issue</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="profile.php">Profile</a></li>
        </ul>

        <div class="navbar__actions">
            <div id="nav-auth-buttons" style="display:flex;gap:.5rem">
                <button class="btn btn-secondary btn-sm" data-auth-open="login">Sign In</button>
                <button class="btn btn-primary btn-sm" data-auth-open="register">Get Started</button>
            </div>
            <div id="nav-user-info" style="display:none;align-items:center;gap:.75rem">
                <span style="font-size:.875rem;color:var(--text-2)">👤 <strong id="nav-user-name"></strong></span>
                <button class="btn btn-secondary btn-sm" data-logout>Sign Out</button>
            </div>
        </div>
    </nav>

    <!-- ═══ HERO ══════════════════════════════════ -->
    <section class="hero">
        <div class="container">
            <div class="hero__eyebrow">🤖 Powered by Gemini AI</div>

            <h1 class="hero__title">
                Report Civic Issues.<br>
                <span class="text-gradient">Get AI-Powered Solutions.</span>
            </h1>

            <p class="hero__desc">
                Snap a photo, describe the problem, and let our AI instantly classify,
                score severity, and recommend action — while authorities track resolution in real time.
            </p>

            <div class="hero__cta">
                <a href="report_issue.php" class="btn btn-primary btn-lg">
                    🚨 Report an Issue
                </a>
                <a href="dashboard.php" class="btn btn-secondary btn-lg">
                    📊 View Dashboard
                </a>
            </div>

            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="hero-stat__value text-gradient"><?= number_format($stats['total'] ?: 0) ?></div>
                    <div class="hero-stat__label">Total Reports</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat__value" style="color:var(--sev-low)"><?= number_format($stats['resolved'] ?: 0) ?></div>
                    <div class="hero-stat__label">Resolved</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat__value" style="color:var(--status-pending)"><?= number_format($stats['pending'] ?: 0) ?></div>
                    <div class="hero-stat__label">Pending</div>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══ LIVE MAP PREVIEW ═══════════════════════ -->
    <section class="section--sm">
        <div class="container">
            <div style="text-align:center;margin-bottom:1.5rem">
                <div class="section-label">Live Intelligence</div>
                <h2>Reported Issues Near You</h2>
                <p class="section-desc" style="margin:0 auto">
                    All active reports are plotted in real time. Marker color indicates severity — green is low, red is critical.
                </p>
            </div>
            <div class="mini-map-wrap">
                <div style="display:flex;align-items:center;justify-content:space-between;padding:.85rem 1.25rem;
                  background:var(--surface);border-bottom:1px solid var(--border)">
                    <span style="font-size:.875rem;font-weight:600">🗺️ Live Report Map</span>
                    <div style="display:flex;gap:1rem;font-size:.78rem;color:var(--text-2)">
                        <span style="color:var(--sev-low)">● Low</span>
                        <span style="color:var(--sev-medium)">● Moderate</span>
                        <span style="color:var(--sev-high)">● High</span>
                        <span style="color:var(--sev-critical)">● Critical</span>
                    </div>
                </div>
                <div id="hero-map"></div>
            </div>
        </div>
    </section>

    <!-- ═══ FEATURES ════════════════════════════════ -->
    <section class="section">
        <div class="container">
            <div style="text-align:center;margin-bottom:3rem">
                <div class="section-label">Platform Features</div>
                <h2>Everything Your City Needs</h2>
            </div>
            <div class="feature-grid">
                <div class="feature-card animate-slide-up delay-1">
                    <span class="feature-icon">🤖</span>
                    <div class="feature-title">Gemini AI Classification</div>
                    <p class="feature-desc">Instant issue categorisation and severity scoring — no manual triage needed.</p>
                </div>
                <div class="feature-card animate-slide-up delay-2">
                    <span class="feature-icon">🗺️</span>
                    <div class="feature-title">Interactive Live Map</div>
                    <p class="feature-desc">All reports geo-tagged and displayed on an interactive map with color-coded severity markers.</p>
                </div>
                <div class="feature-card animate-slide-up delay-3">
                    <span class="feature-icon">📊</span>
                    <div class="feature-title">Real-Time Analytics</div>
                    <p class="feature-desc">Pie, line, and bar charts give authorities instant visibility into infrastructure trends.</p>
                </div>
                <div class="feature-card animate-slide-up delay-1">
                    <span class="feature-icon">🔐</span>
                    <div class="feature-title">Secure & Private</div>
                    <p class="feature-desc">BCrypt password hashing, CSRF protection, and PDO prepared statements keep data safe.</p>
                </div>
                <div class="feature-card animate-slide-up delay-2">
                    <span class="feature-icon">📸</span>
                    <div class="feature-title">Photo Evidence</div>
                    <p class="feature-desc">Attach photo evidence to your report. Our AI factors images into its severity analysis.</p>
                </div>
                <div class="feature-card animate-slide-up delay-3">
                    <span class="feature-icon">📡</span>
                    <div class="feature-title">Live Status Tracking</div>
                    <p class="feature-desc">Follow your report from Pending → In Progress → Resolved with real-time dashboard updates.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══ HOW IT WORKS ════════════════════════════ -->
    <section class="section" style="background:var(--surface);border-top:1px solid var(--border);border-bottom:1px solid var(--border)">
        <div class="container">
            <div style="text-align:center;margin-bottom:3rem">
                <div class="section-label">Process</div>
                <h2>How It Works</h2>
            </div>
            <div class="steps-grid">
                <div class="step-card">
                    <div class="step-num">1</div>
                    <h3 style="margin-bottom:.5rem">Submit Report</h3>
                    <p style="color:var(--text-2);font-size:.875rem">Describe the issue, add a photo, and let us capture your GPS location automatically.</p>
                </div>
                <div class="step-card">
                    <div class="step-num">2</div>
                    <h3 style="margin-bottom:.5rem">AI Analysis</h3>
                    <p style="color:var(--text-2);font-size:.875rem">Gemini AI classifies the issue, assigns a severity score 0–100, and writes a summary.</p>
                </div>
                <div class="step-card">
                    <div class="step-num">3</div>
                    <h3 style="margin-bottom:.5rem">Dashboard Alert</h3>
                    <p style="color:var(--text-2);font-size:.875rem">Authorities see the report appear on the live map and analytics dashboard instantly.</p>
                </div>
                <div class="step-card">
                    <div class="step-num">4</div>
                    <h3 style="margin-bottom:.5rem">Resolution</h3>
                    <p style="color:var(--text-2);font-size:.875rem">Teams dispatch, update the status in real time, and the issue moves to Resolved.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══ RECENT REPORTS ══════════════════════════ -->
    <?php if (!empty($latestReports)): ?>
        <section class="section">
            <div class="container">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
                    <div>
                        <div class="section-label">Live Activity</div>
                        <h2>Latest Reports</h2>
                    </div>
                    <a href="dashboard.php" class="btn btn-secondary">View All →</a>
                </div>
                <div class="reports-preview">
                    <?php foreach (array_slice($latestReports, 0, 6) as $r): ?>
                        <?php
                        $score  = $r['ai_severity_score'];
                        $scoreColor = $score !== null
                            ? ($score <= 30 ? '#22c55e' : ($score <= 60 ? '#eab308' : ($score <= 80 ? '#f97316' : '#ef4444')))
                            : '#6b7280';
                        $catIcons = ['pothole' => '🕳️', 'electrical' => '⚡', 'flooding' => '🌊', 'waste' => '🗑️', 'structural damage' => '🏗️', 'other' => '📌'];
                        $catIcon  = $catIcons[$r['ai_category'] ?? ''] ?? '📌';
                        ?>
                        <div class="report-preview-card">
                            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.75rem">
                                <span style="font-size:1.5rem"><?= $catIcon ?></span>
                                <?php if ($score !== null): ?>
                                    <span style="font-size:.8rem;font-weight:700;color:<?= $scoreColor ?>;
                background:<?= $scoreColor ?>22;padding:2px 8px;border-radius:99px">
                                        <?= $score ?>
                                    </span>
                                <?php endif ?>
                            </div>
                            <h4 style="margin-bottom:.4rem;font-size:.95rem"><?= htmlspecialchars($r['title']) ?></h4>
                            <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap">
                                <?php if ($r['ai_category']): ?>
                                    <span style="font-size:.72rem;background:var(--surface-2);color:var(--text-3);padding:2px 7px;border-radius:99px">
                                        <?= htmlspecialchars($r['ai_category']) ?>
                                    </span>
                                <?php endif ?>
                                <span style="font-size:.72rem;background:var(--surface-2);color:var(--text-3);padding:2px 7px;border-radius:99px">
                                    <?= htmlspecialchars($r['status']) ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach ?>
                </div>
            </div>
        </section>
    <?php endif ?>

    <!-- ═══ CTA BANNER ══════════════════════════════ -->
    <section class="section">
        <div class="container">
            <div class="cta-banner">
                <div style="font-size:3rem;margin-bottom:1rem;animation:float 3s ease-in-out infinite">🌍</div>
                <h2 style="margin-bottom:.75rem">See Something? Report It.</h2>
                <p style="color:var(--text-2);max-width:500px;margin:0 auto 2rem;font-size:1.05rem">
                    Every report you submit makes your community safer.
                    It takes less than 60 seconds.
                </p>
                <a href="report_issue.php" class="btn btn-primary btn-lg">
                    🚨 Submit a Report Now
                </a>
            </div>
        </div>
    </section>

    <!-- ═══ FOOTER ═══════════════════════════════════ -->
    <footer class="footer">
        <div class="container">
            <p>🛡️ <strong>CivicShield AI</strong> — Built with Gemini AI, Leaflet.js & Chart.js &nbsp;|&nbsp;
                <a href="dashboard.php">Dashboard</a> &nbsp;|&nbsp;
                <a href="report_issue.php">Report Issue</a>
            </p>
        </div>
    </footer>

    <div id="toast-container"></div>

    <!-- Scripts -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
    <script src="https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js"></script>
    <script src="assets/js/utils.js"></script>
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/map.js"></script>
    <script>
        // Hamburger
        document.getElementById('hamburger').addEventListener('click', () => {
            document.getElementById('navbar-links').classList.toggle('open');
        });

        // Init hero map
        const heroMap = initMap('hero-map', {
            zoom: 12
        });
        const reports = <?= json_encode($latestReports) ?>;
        loadMarkers(heroMap, reports, {
            fitBounds: reports.length > 0
        });
    </script>
</body>

</html>