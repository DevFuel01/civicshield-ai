<?php
// ─────────────────────────────────────────────
//  CivicShield AI — Database Configuration
// ─────────────────────────────────────────────

define('DB_HOST', 'localhost');
define('DB_NAME', 'civicshield');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Gemini AI Configuration
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// App Configuration
define('BASE_URL', 'http://localhost/CivicShieldAI');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_MIME_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
define('SESSION_TIMEOUT', 1800); // 30 minutes

// Session Configuration
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    // ini_set('session.cookie_secure', 1); // Enable if using HTTPS
    session_start();
}

// Inactivity check
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_unset();
        session_destroy();
        if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
            jsonResponse(['error' => 'Session expired. Please log in again.'], 401);
        } else {
            header('Location: ' . BASE_URL . '/index.php?timeout=1');
            exit;
        }
    }
    $_SESSION['last_activity'] = time();
}

/**
 * Logs errors to a persistent file with context
 */
function logError(string $message, ?Throwable $e = null): void
{
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) mkdir($logDir, 0777, true);

    $timestamp = date('Y-m-d H:i:s');
    $uri      = $_SERVER['REQUEST_URI'] ?? 'CLI';
    $method   = $_SERVER['REQUEST_METHOD'] ?? 'N/A';
    $userId   = $_SESSION['user_id'] ?? 'guest';
    $errText  = $e ? " | Exception: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine() : "";

    $entry = "[$timestamp] [$method $uri] [User: $userId] $message$errText" . PHP_EOL;
    file_put_contents($logDir . '/error.log', $entry, FILE_APPEND);
}

/**
 * Returns a PDO database connection (singleton pattern)
 */
function getDB(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            logError("Database connection failed", $e);
            jsonResponse(['error' => 'Database connection failed.'], 500);
        }
    }
    return $pdo;
}

/**
 * Send a standardized JSON response and exit
 */
function jsonResponse(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');

    // Security Headers
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https://*.tile.openstreetmap.org;");

    echo json_encode($data);
    exit;
}

/**
 * Get or generate a CSRF token for the current session
 */
function getCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate CSRF token from request header or POST body
 */
function validateCsrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');

    // For multipart/form-data, we might need to check $_POST if header is missing
    if (empty($token) && !empty($_POST['csrf_token'])) {
        $token = $_POST['csrf_token'];
    }

    if (empty($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        logError("CSRF validation failed for user " . ($_SESSION['user_id'] ?? 'guest'));
        jsonResponse(['error' => 'Invalid CSRF token.'], 403);
    }
}

/**
 * Require authenticated session; exit with 401 if not
 */
function requireAuth(): array
{
    if (empty($_SESSION['user_id'])) {
        jsonResponse(['error' => 'Authentication required.'], 401);
    }
    return [
        'id'   => $_SESSION['user_id'],
        'role' => $_SESSION['user_role'] ?? 'citizen',
        'name' => $_SESSION['user_name'] ?? '',
    ];
}

/**
 * Rate limiting: max $max requests per $windowSeconds per session
 */
function rateLimit(string $key, int $max = 10, int $windowSeconds = 3600): void
{
    $now = time();
    $bucket = &$_SESSION["rl_{$key}"];
    if (!isset($bucket) || ($now - $bucket['start']) > $windowSeconds) {
        $bucket = ['count' => 0, 'start' => $now];
    }
    $bucket['count']++;
    if ($bucket['count'] > $max) {
        jsonResponse(['error' => 'Rate limit exceeded. Please try again later.'], 429);
    }
}
/**
 * Log an event to the report timeline
 */
function logTimeline(int $reportId, string $status, ?string $message = null): void
{
    try {
        $db   = getDB();
        $stmt = $db->prepare('INSERT INTO report_timeline (report_id, status, message) VALUES (?, ?, ?)');
        $stmt->execute([$reportId, $status, $message]);
    } catch (PDOException $e) {
        logError("Failed to log timeline event for report $reportId", $e);
    }
}
